import java.sql.Connection;
import java.sql.Statement;

class Create {
	public static void main(String args[]) throws Exception {
		// Connection c = HsEmDs.getConnection();
		Connection c = HsServDs.getConnection();

		Statement s = c.createStatement();
		s.executeUpdate("CREATE TABLE student(id INTEGER, name VARCHAR(20))");
		s.executeUpdate("INSERT INTO student VALUES (123, 'John Rambo')");
		s.executeUpdate("INSERT INTO student VALUES (7, 'Jame Bond')");
		s.executeUpdate("INSERT INTO student VALUES (666, 'Jack Ripper')");
		c.close();
		
		System.out.println("Create ok.");
	}
}