import java.sql.*;

public class SqliteDs {
	public static Connection getConnection() {
		try {
			Class.forName("org.sqlite.JDBC");
			return DriverManager.getConnection("jdbc:sqlite:mydb");
		} catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		return null;
	}
}

/*
jdbc:h2:~/mydb 			user home directory
jdbc:h2:/data/mydb		directory c:/data
jdbc:h2:mydb			current(!) working directory
*/