import java.sql.*;

class Select {
	public static void main(String args[]) throws Exception {	
		Connection c = SqliteDs.getConnection();
		
		Statement s = c.createStatement();
		ResultSet r = s.executeQuery("SELECT * FROM student");
		while (r.next())
			System.out.println(r.getInt(1) + "," + r.getString(2));
		s.close();
		c.close();
	}
}
