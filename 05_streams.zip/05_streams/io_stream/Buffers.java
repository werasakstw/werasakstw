/*	Stream with Buffer:
	   BufferedInputStream
	 	BufferedOutputStream

		BufferedReader
		BufferedWriter

BufferedReader.readLine()		reads to end of line into a string.
BufferedWriter.write(String)  */
import java.io.*;
class ByteBuffer {
// class Buffers {
	public static void main(String args[]) throws IOException {
		BufferedInputStream bis = new BufferedInputStream(System.in);
		BufferedOutputStream bos = new BufferedOutputStream(System.out);
		int c;
		while ((c = bis.read()) != -1)
			bos.write(c);
		bis.close();
		bos.close();
	}
} // Try: java Buffers.java <Buffers.java

// class CharBuffer {
class Buffers {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		String s;
		while ((s = br.readLine()) != null)
			bw.write(s + "\n");
		bw.close();
	}
} // Try: java Buffers.java <Buffers.java
