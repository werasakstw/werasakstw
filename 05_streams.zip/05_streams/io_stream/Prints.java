/* Streams that write simple types and object as string.

public class java.io.PrintStream extends java.io.FilterOutputStream implements java.lang.Appendable,java.io.Closeable
	public java.io.PrintStream(java.io.OutputStream);
	public java.io.PrintStream(java.io.OutputStream, boolean);
	public java.io.PrintStream(java.lang.String) throws java.io.FileNotFoundException
	public java.io.PrintStream(java.io.File) throws java.io.FileNotFoundException;

public class java.io.PrintWriter extends java.io.Writer
	public java.io.PrintWriter(java.io.OutputStream)
	public java.io.PrintWriter(java.io.Writer)
	public java.io.PrintWriter(java.lang.String) throws java.io.FileNotFoundException
	public java.io.PrintWriter(java.io.File) throws java.io.FileNotFoundException

	public void print(boolean);
	public void print(char);
	public void print(int);
	public void print(long);
	public void print(float);
	public void print(double);
	public void print(char[]);
	public void print(String);
	public void print(Object);

	public void println();
	public void println(boolean);
	public void println(char);
	public void println(int);
	public void println(long);
	public void println(float);
	public void println(double);
	public void println(String);
	public void println(Object);   */
import java.io.*;
import java.util.*;
class Print {
// class Prints {
	public static void main(String args[]) {
		PrintStream pw = new PrintStream(System.out);
		pw.println(true);
		pw.println(Byte.MAX_VALUE);
		pw.println(Short.MAX_VALUE);
		pw.println('A');
		pw.println(Integer.MAX_VALUE);
		pw.println(Long.MAX_VALUE);
		pw.println(Float.MAX_VALUE);
		pw.println(Double.MAX_VALUE);
		pw.println("Hello");
		pw.println(new Date()); // The object is toString().
	}
}

// Print to file.
class PrintFile {
// class Prints {
	public static void main(String args[]) {
		PrintWriter pw = null;
		try {
			pw = new PrintWriter("tmp.txt");
		} catch(FileNotFoundException e) {
			System.err.println(e);
		}
		pw.println("Hello! how do you do?");
		pw.close();
	}
}

/* Java 5 introduced printf().
 public java.io.PrintStream printf(java.lang.String, java.lang.Object...)
 public java.io.PrintWriter printf(java.lang.String, java.lang.Object...)
*/
class Printf {
// class Prints {
	public static void main(String args[]) {
		System.out.printf("There are %d %s.", 10, "books");
	}
}
