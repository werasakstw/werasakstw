/* An 'auto closeable' class must implement AutoCloseable interface,
 which has a close() method. */
import java.io.*;
class A implements AutoCloseable {
		public void hello() {				// resource-specific method
			System.out.println("Hello.");
		}
		@Override
		public void close() throws Exception {
			System.out.println("Goodbye!");
		}
}
/* Java 7 introduces 'resource block' in the try-catch.
		try (<resource block>) { } catch () {<catch block>}
All objects created in resource block must implement AutoCloseable.
The close() of objects created in resource block will be executed automatically
 // when the try block exits. No matter an exception is thrown or not. */
class ResourceBlock {
// class AutoClose {
	public static void main(String args[]) {
		try ( A a = new A(); ) {
			a.hello();
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
//-----------------------------------------------

// Closing a stream properly is very awkward.
class PreJava7 {
// class AutoClose {
	public static void main(String args[]) {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("index.txt"));
			String s;
			while ((s = br.readLine()) != null)
				System.out.println(s);
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

// Using Resources Block.
// class Java8 {
class AutoClose {
	public static void main(String args[]) {
		try (
			BufferedReader br = new BufferedReader(new FileReader("index.txt"));
		) {
			String s;
			while ((s = br.readLine()) != null)
				System.out.println(s);
		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
