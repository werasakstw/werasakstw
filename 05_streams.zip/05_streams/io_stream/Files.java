import java.io.*;
// A File object represents file/director and provides information.
class FileInfo {
// class Files {
	public static void main(String args[]) {
		File f = new File("Files.java");
		System.out.println("Exists: "+f.exists());
		System.out.println("File name: "+f.getName());
		System.out.println("Parent: "+f.getParent());
		System.out.println("Path: "+f.getPath());
		System.out.println("AbsolutePath: "+f.getAbsolutePath());
		System.out.println("Readable: "+f.canRead());
		System.out.println("Writable: "+f.canWrite());
		System.out.println("isDirectory: "+f.isDirectory());
		System.out.println("isFile: "+f.isFile());
		System.out.println("Length: "+f.length());
		System.out.println(File.separatorChar);

		// List files in a directory.
		File d = new File(".");
		File fs[] = d.listFiles();
		for (File i : fs)
			System.out.print(i.getName() + ", ");
	}
}

// File Name Filter
class MyFilter implements FileFilter {
	String x;
	MyFilter(String x) { this.x = x; }
	public boolean accept(File f) {
		return f.getName().endsWith(x);
	}
}
class FilterTest {
// class Files {
	public static void main(String args[]) {
		File d = new File(".");
		File f[] = d.listFiles(new MyFilter(".java"));
		for (File i : f)
			System.out.println(i.getName());
	}
}

// Create, Rename, Delete
// class FileManipulate {
class Files {
	public static void main(String[] args) throws IOException {
		File f = new File("tmp.txt");
		System.out.println(f.createNewFile());
		System.out.println(f.exists());
		System.out.println(f.renameTo(new File("t.txt")));
		// System.out.println(f.delete());
	}
}
