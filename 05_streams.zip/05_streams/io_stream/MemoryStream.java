/* Java allowsusing memory as streams.
   	ByteArrayInputStream
 		ByteArrayOutputStream

		CharArrayReader
		CharArrayWriter

		StringReader
		StringWriter   */
import java.io.*;
class Memory {
// class MemoryStream {
	public static void main(String args[]) throws IOException {
		// byte array stream
		byte b[] = {72, 101, 108, 108, 111};
		ByteArrayInputStream bai = new ByteArrayInputStream(b);
		ByteArrayOutputStream bao = new ByteArrayOutputStream();
		int x;
		while ((x = bai.read()) != -1)
			bao.write(x);
		bai.close(); bao.close();
		// bao.writeTo(System.out);
		System.out.println(new String(bao.toByteArray(),0,5));

		// char array stream
		char c[] = {'H','e','l','l','o'};
		CharArrayReader car = new CharArrayReader(c);
		CharArrayWriter caw = new CharArrayWriter();
		while ((x = car.read()) != -1)
			caw.write(x);
		car.close(); caw.close();
		System.out.println(caw.toString());

		// string stream
		String s = "Hello";
		StringReader sr = new StringReader(s);
		StringWriter sw = new StringWriter();
		while ((x = sr.read()) != -1)
			sw.write(x);
		sr.close(); sw.close();
		System.out.println(sw.toString());
	}
}

/* Pipe is a stream that is writen at one end and
  read from another end.

		PipedInputStream
		PipedOutputStream

		PipedReader
		PipedWriter   */
// class Pipe {
class MemoryStream {
	static class Producer extends Thread {
		PipedOutputStream pout;
		Producer(PipedOutputStream pout) { this.pout = pout; }
		public void run() {
			try {
				for (int i = 0; i < 10; i++) {
					pout.write(i);
					System.out.println("write: "+i);
					sleep((int)(Math.random()*3000));
				}
			} catch (Exception e) { }
		}
	}
	static class Consumer extends Thread {
		PipedInputStream pin;
		Consumer(PipedInputStream pin) { this.pin = pin; }
		public void run() {
			try {
				for (int i = 0; i < 10; i++) {
					int x = pin.read();
					System.out.println("read: " + x);
					sleep((int)(Math.random()*3000));
				}
			} catch (Exception e) { }
		}
	}
	public static void main(String agrs[]) throws IOException {
		PipedInputStream pin = new PipedInputStream();
		PipedOutputStream pout = new PipedOutputStream(pin);
		new Producer(pout).start();
		new Consumer(pin).start();
	}
}
