/* Streams are sequences of elements, with a set of aggregate operations.
Collections concern with efficiency for accessing elements.
Streams concern with efficiency for operations on elements.

Streams have no storages, its operation performs on element that comes
 from input and the result is passed out automatically.
Streams are faster and use less memory than using collections.

Stream programming:
   1. Data source provides data to be performed.
   2. Construct a chain of intermediate operations to perform on data.
   3. Using a terminal operation to collect or produce the result.
That allows thinking declaratively what to do on data without
 concerning with moving data and store intermediate results.  */
import java.io.*;
import java.util.*;
import java.util.stream.*;
import java.util.function.*;
interface MyUtil {
    public static String names[ ] = { "John", "Jack", "Joe" };
    public static Consumer<Object> sout = s -> System.out.print(s + ",");
    public static void prints(Stream<?> ss) {
        ss.forEach(s -> System.out.print(s + ","));
        System.out.println();
    }
}
class CreateStream {
// class Streams {
	public static void main(String[] args) {
	// Stream.of(T) creates a stream from a type parameter.
		Stream<String> s1 = Stream.of(MyUtil.names);
		MyUtil.prints(s1);

	// Arrays.stream(<array>) creates a stream from an array.
		MyUtil.prints(Arrays.stream(MyUtil.names));

	// Collection.stream() creates a stream from a collection.
		List<String> ls = Arrays.asList(MyUtil.names);
		MyUtil.prints(ls.stream());

	// empty() create an empty stream
		MyUtil.prints(Stream.empty());

	// Stream.of(<vararg>) creates a stream from a arg-var.
		MyUtil.prints(Stream.of("Jim", "Jame", "Janet"));
		MyUtil.prints(Stream.of("john-jack-joe".split("-")));  // split() is a String method.

	/* Streams may be infinite.
	Streams.generate() creates an infinite stream form a function.
	limit() cuts off the stream.   */
		Stream<Double> sd = Stream.generate(Math::random).limit(3);
		MyUtil.prints(sd);

	/* Stream.iterate() creates an infinite stream form an initial
    value and an update function. */
		Stream<Integer > si = Stream.iterate(0, x -> ++x).limit(5);
		MyUtil.prints(si);
	}
}

// Java allows three kinds of primitive streams: int, long, double.
class PrimitiveStream {
// class Streams {
   /* sum() is a terminal operation that sums all elements in
   the stream and returns result as a single value. */
	public static void main(String[] args) {
	// IntStream for stream of int.
		int sum3 = IntStream.of(1, 2, 3).sum();
		System.out.println("sum3 = " + sum3);

	// LongStream
		long sum4 = LongStream.of(1L, 2L, 3L).sum();
		System.out.println("sum4 = " + sum4);

	// DoubleStream.
		double sum5 = DoubleStream.of(1.0, 2.0, 3.0).sum();
		System.out.println("sum5 = " + sum5);

   /* sum() on primitive stream returns a value of the type.
   But sum() on object streams returns an optional of the type.
	   Stream of Integer   */
		Optional<Integer> sum1 = Stream.of(1, 2, 3).reduce(Integer::sum);
		if(sum1.isPresent())
			System.out.println("sum1 = " + sum1.get());

	/* Stream.mapToInt() map stream of Object to a stream of int.
	   There are also mapToLong() and mapToDouble(). */
		int sum2 = Stream.of(1, 2, 3).mapToInt(x -> x).sum();
		System.out.println("sum2 = " +  sum2);
	}
}
//----------------------------------------------------------
/* A terminal operation must be the last operation on a stream.
Once a terminal operation is invoked, the stream is "consumed"
 and is no longer usable.  */
class Terminals {
// class Streams {
	public static void main(String[] args) {
	// Stream.forEach(<consumer>) performs the consumer for each element.
		Stream.of(MyUtil.names)
			.forEach(s -> System.out.print(s + ","));
		System.out.println();

	// Stream.toArray() dumps all elements into an array.
		Object sa[ ] = Stream.of(MyUtil.names).toArray();
		System.out.println(Arrays.asList(sa));

	// count() return the number of elements.
		long c = Stream.of(MyUtil.names).count();
		System.out.println(c);

	// min()/max() returns an option<T>
		int m = Stream.of(3, 2, 5, 6, 3, 1)
			.max(Integer::compareTo)
			.get();
		System.out.println(m);

   // Alternatively
      Stream.of(1, 2, 3).min(Integer::compareTo).ifPresent(System.out::println);
   }
}

/* A 'short-circuit' operation can stop processing elements in the
 stream if an answer is found without examining all the elements.
 ex. limit(), skip(), findAny(), findFirst(), anyMatch(), and
  allMatch() are short-circuit, but count(), min(), max(), and
  noneMatch() are not. */
class ShortCircuit {
// class Streams {
	public static void main(String[] args) {
	// findAny() returns any element of the stream, or an empty if the stream is empty.
		System.out.println(Stream.of(2, 1, 3).findAny().get());

	// findFirst() returns the first element, or an empty if the stream is empty.
		System.out.println(Stream.of(3, 1, 5, 4, 2).findFirst().get());

	// anyMatch(<predicate>) returns a boolean 'true' if there is an element match the predicate, else returns 'false'.
		System.out.println(Stream.of(3, 4, 1, 5).anyMatch(x -> x % 2 == 0));

	// allMatch(<predicate>) returns a boolean 'true' if all elements match the predicate, else returns 'false'.
		System.out.println(Stream.of(3, 7, 1, 5).allMatch(x -> x % 2 != 0));

	// noneMatch(<predicate>) returns a boolean 'true' if there is no elements match the predicate, else returns 'false'.
		System.out.println(Stream.of(3, 7, 1, 2).noneMatch(x -> x % 2 == 0));
	}
}

/* After a terminal operation is performed the stream is closed.
To use a stream more than once, we need a stream supplier. */
class Reuse {
// class Streams {
	public static void main(String[] args) {
		Stream<String> ss = Stream.of("A", "B", "C");
      MyUtil.prints(ss);
      // MyUtil.prints(ss);         // error

      // A stream supplier is created with a supplier that create the stream.
		Supplier<Stream<String>> sss = () -> Stream.of("X", "Y", "Z");
      MyUtil.prints(sss.get());
      MyUtil.prints(sss.get());
	}
}

/* Reduce: The operators that reduce the elements into a value.
      Optional<T> reduce(BinaryOperator<T> accumulator)
	  T reduce(T identity, BinaryOperator<T> accumulator)
	  T reduce(T identity, BinaryOperator<T> accumulator, BinaryOperator<T> combiner)
*/
class Reduce {
// class Streams {
	public static void main(String[] args) {
		System.out.println(Stream.of(1, 2, 3).reduce(Integer::sum).get());
		System.out.println(Stream.of(1, 2, 3).reduce(0, (a, b) -> a + b));
		System.out.println(Stream.of(1, 2, 3).reduce(Integer.MIN_VALUE, Integer::max));
		System.out.println(Stream.of("a", "b", "c").reduce(":", String::concat));
	}
}

/* Collect: The operators that collects the elements into a sequence, ex. e.g. List, Set or Map.
	  R collect(Supplier<R> supplier,
				BiConsumer<R,? super T> accumulator,
				BiConsumer<R,R> combiner)              */
class Collect {
// class Streams {
	public static void main(String[] args) {
		List<String> l = Stream.of("John", "Jack", "Joe")
				.collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
		System.out.println(l);

   /* Collector Object:
   Collector.of() create a collector object from lambda that are passed as parameters.
   It may collect the elements into the specified type.   */
		Collector<String, StringJoiner, String> co =
   			Collector.of(
   				() -> new StringJoiner(" | "),  // supplier
   				(j, s) -> j.add(s),             // accumulator
   				(j1, j2) -> j1.merge(j2),       // combiner
   				StringJoiner::toString);        // finisher
		String s = Stream.of("John", "Jack", "Joe").collect(co);
		System.out.println(s);
	}
}
//--------------------------------------------------------

/* Intermediate operators are operators between source and terminal.
They operate on elements one at a time by take input from the left and pass result to the right.
They keeps the stream open so that chaining operations is possible.  */
class Intermediate {
// class Streams {
	public static void main(String[] args) {
	// Aggregate Operations:
	// map(<Function>) applies the <Function> to each elements one by one.
		Stream.of(MyUtil.names)
			.map(s -> s.toUpperCase())
			.forEach(MyUtil.sout);
		System.out.println();

	// filter(<Predicate>) apply the <Predicate> to each elements and allows only the elements
	// that the predicate returns true to pass through the stream.
		Stream.of(MyUtil.names)
			.filter(s -> s.startsWith("Jo"))
			.forEach(MyUtil.sout);
		System.out.println();

	// filter() is not a short-circuit operation.
		Stream.of(MyUtil.names)
			.filter(s -> {
				if (s.equals("Jack"))
					return false;
				return true;
			})
			.forEach(MyUtil.sout);
		System.out.println();

	// distinct() returns a stream in the same order, except the duplicates are suppressed.
		Stream.of( 2, 4, 1, 3, 1, 1, 5, 2, 3)
			.distinct()
			.forEach(MyUtil.sout);
		System.out.println();

	// sorted(<Comparator>) returns the stream that is sorted by the comparator.
		Stream.of(MyUtil.names)
			.sorted(String::compareTo)
			.forEach(MyUtil.sout);
		System.out.println();

	// limit(<number>) cuts off the stream to only <number> elements.
	// limit() is a stateful and short-circuiting operation.
		Stream.of( 0, 1, 2, 3, 4, 5, 6 )
			.limit(3)
			.forEach(MyUtil.sout);
		System.out.println();

	// skip(<number>) cuts off the first <number> elements of the stream.
	// skip() is a stateful operation.
		Stream.of( 0, 1, 2, 3, 4, 5, 6 )
			.skip(3)
			.forEach(MyUtil.sout);
		System.out.println();

   /* peek(<Consumer>) apply the <Consumer> on each elements that pass through the stream.
		but peek() is lazy we need to force the execution by collect() or toArray() */
		Object n[] = Stream.of(MyUtil.names)
			.peek(MyUtil.sout)
			.toArray();			// .collect(Collectors.toList());
      System.out.println(Arrays.asList(n));
	}
}

/* A lazy intermediate operator will be executed only when its result
is requested from the next operation. */
class Lazy {
// class Streams {
	public static void main(String[] args) {
		// Starting at the terminal each operator requests input from the left.
		Object a[] = Stream.of(1, 2, 3)
				.peek(x -> System.out.print("before: " +  x))
				.map(x -> x * x)
				.peek(x -> System.out.println(" after: "+ x))
				.toArray();
		System.out.println(Arrays.asList(a));
	}
}

/* Pruning is the process of reducing the number of operations to be performed.
  - using 'short circuit' operator.
  - reordering the operator chain.   */
class Pruning {
// class Streams {
	public static void main(String[] args) {
		Stream.of(1, 2, 3)
			.map(x -> {
				System.out.print("\nmap: " + x + ", ");
				return x * x;
			})
			.filter(x -> {
				System.out.print("filter: " + x + ", ");
				return (x % 2) == 0;
			})
			.forEach(x -> System.out.print("forEach: " + x));
		System.out.println();

		// The stream is pruned if performs filter before map.
		Stream.of(1, 2, 3)
			.filter(x -> {
				System.out.print("\nfilter: " + x + ", ");
				return (x % 2) == 0;
			})
			.map(x -> {
				System.out.print("map: " + x + ", ");
				return x * x;
			})
			.forEach(x -> System.out.print("forEach: " + x));
	}
}

/* Normally elements are passed through a stream one at a time.
If an operation does not have to remember what elements it had performed so far,
it is a 'stateless' operation.
 ex. filter(), map(), anyMatch(), findAny(), findFirst(), forEach(), collect().

If an operation has to remember the elements it had encountered it is a 'stateful' operation.
 ex. distinct(), skip(), limit(), sorted(), reduce().

 Stateless is more efficient because it allows short-circuit
  and pruning. */
class Stateful {
// class Streams {
	public static void main(String[] args) {

		// Some stateful operations must complete the operations on all elements before
		// passing to the next operation, so it behave as a data source.
		// ex. sorted() is a stateful data source operation.
		Stream.of(2, 1, 3)
			.peek(x -> System.out.print("\nbefore: " +  x))
			.sorted((x1, x2) -> {
				System.out.printf("\nsort: %s; %s", x1, x2);
				return x1.compareTo(x2);
			})
			.peek(x -> System.out.print("\nafter: " +  x))
			.forEach(s ->
					System.out.print(" forEach: " + s)
			);
		System.out.println("\n---------------------------------------------");


		// max(), min() are stateful data source operation.
		Stream.of(2, 5, 1, 4, 3)
			.max((x, y) ->  {
				System.out.printf("\nmax: %d; %d", x, y);
				return x - y;
			})
			.ifPresent(s ->
					System.out.print(" ifPresent: " + s)
			);
		System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++");


		// Some stateful operations just remember the state of the performed elements and
		// pass some result to the next operation before all elements had encountered.
		// These operation are calle stateful intermediate.
		//  ex. limit() allows short circuit.
		//	ex. skip() and distinct() allow pruning.
		Stream.of(3, 1, 2, 2, 1, 4, 3)
			.peek(s -> System.out.print("\nbefore: " + s + ", "))
			.distinct()
			.peek(s -> System.out.print("after: " + s + ", "))
			.forEach(s -> System.out.print("forEach: " + s));
		System.out.println("\n************************************************");

		// There may be more than one stateful operations in a chain.
		Stream.of(4, 2, 3, 1)
			.sorted((x1, x2) -> {
				System.out.printf("\nsort: %s; %s", x1, x2);
				return x1.compareTo(x2);
			})
			.max((x, y) ->  {
				System.out.printf("\nmax: %d; %d", x, y);
				return x - y;
			})
			.ifPresent(s -> System.out.print(" ifPresent: " + s));
	}
}
