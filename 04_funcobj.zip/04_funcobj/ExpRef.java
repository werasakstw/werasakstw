/* Java allows using already existing methods as lambda expression:
		 		<class>::<static method>
				<instance>::<instance method>
  e.g. Using String methods.    */
import java.io.*;
import java.util.*;
import java.util.function.*;
class PrintlnTest {
// class ExpRef {
	public static void main(String[] args) {
		Consumer<String> c1 = x -> System.out.println(x);
		c1.accept("Hello");

		PrintStream ps = new PrintStream(System.out);
		Consumer<String> c2 = ps::println;
		c2.accept("Hi");

		// System.out is an instance of java.io.PrintStream.
		Consumer<String> c3 = System.out::println;
		c3.accept("What's Up?");
	}
}

// Using our class methods.
class A {
	static void hello(String name) {
		System.out.println("Hello " + name);
	}
	void hi(String name) {
		System.out.println("Hi " + name);
	}
	static Consumer<String> getHello() { return A::hello; }
	Consumer<String> getHi() { return new A()::hi; }
}
class ATest {
// class ExpRef {
	public static void main(String[] args) {
		A.getHello().accept("John");
		new A().getHi().accept("Jack");
	}
}

// Constructor reference:  <class>::new.
interface Factory<T, U> {
	T create(U u);
}
interface ArrayFactory<T> {
	T[ ] create(int n);
}
interface ListFactory<T> {
	List<T> create();
}
class Student {
	String name;
	Student(String name) { this.name = name; }
	public String toString() { return name; }
}
// class ConstructorRef {
class ExpRef {
	public static void main(String[] args) {
		Factory<Student, String> fac = Student::new;
		Student john = fac.create("John");
		System.out.println(john);

		ArrayFactory<Student> afac = Student[]::new;
		Student sa[] = afac.create(10);
		System.out.println(sa.length);

		ListFactory<Student> lfac = ArrayList<Student>::new;
		List<Student> l = lfac.create();
		System.out.println(l.size());
	}
}
