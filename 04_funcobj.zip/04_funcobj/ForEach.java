/* In Java 8, forEach() has been added to the Iterable interface,
  which is a super-interface of Collection. So all Collection
  objects can be froEach().   */
import java.util.*;
import java.util.function.*;
class ForEachTest {
// class ForEach {
	public static void main(String[] args) {
		List<String> a = Arrays.asList("John", "Jack", "Joe");

	// External Iteration: The users control the iteration through 'for'
	//  which uses the iteration method provided by the class of the object.
		for(String x : a)
			System.out.print(x + ",");
		System.out.println();

	// Internal Iteration: The users delegate the 'loop' control to the
	//  library and provide a functional to be performed at each iterations.
		a.forEach(x -> System.out.print(x + ","));
		System.out.println();

	/* External iteration must concern with 'how' to iterate and 'what' to do
	with each iteration. While internal iteration concern only with 'what'.
	The library can optimize iteration performance by using laziness,
	parallelism, and out-of-order execution. None of these is user concern.
	*/

	/* Using 'return' just terminates the current iteration and continue the next.
	There is no way to terminate the rest of forEach loop.
	forEach accepts a consumer lambda, so it cannot return a value. */
		a.forEach(x -> {
			if (x.equals("Jack"))
				return;
			System.out.println("Hi " + x);
		});
		System.out.println();
	}
}

/* forEach() increases performance of passing result
  between loops.  */
class MyMath {
	static int _double(int x) {
		return x + x;
	}
	static int sq(int x) {
		return x * x;
	}
	static IntUnaryOperator getDouble() { return MyMath::_double; }
	static IntUnaryOperator getSq() { return MyMath::sq; }
}
// class Composition {
class ForEach {

	public static void main(String[] args) {
		// Explicit loops need tostore intermediate results.
		List <Integer> a = Arrays.asList(1, 2, 3);
		List<Integer> a1 = new ArrayList<Integer>();
		for (Integer x : a)
			a1.add(MyMath._double(x));
		List<Integer> a2 = new ArrayList<Integer>();
		for (Integer x : a1)
			a2.add(MyMath.sq(x));
		for (Integer x : a2)
			System.out.print(x  + ", ");
		System.out.println();

		/* forEach() allows composition more than one functions
		 without storing intermediate result. */
		IntUnaryOperator db = MyMath.getDouble();
		IntUnaryOperator sq = MyMath.getSq();
		a.forEach(x -> System.out.print(sq.applyAsInt(db.applyAsInt(x)) + ", "));
	}
}
