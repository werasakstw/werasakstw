import javax.management.*;
import com.sun.jdmk.comm.*;
public class Server {
	public static void main(String args[]) throws Exception {
		ObjectName on = new ObjectName("HelloAgent:name=helloMBean");
		MBeanServer mbs = MBeanServerFactory.createMBeanServer("HelloAgent" );
		mbs.registerMBean(new Hello(), on);
		HtmlAdaptorServer as = new HtmlAdaptorServer();
		as.setPort(1234);
		mbs.registerMBean(as, new ObjectName("HelloAgent:name=htmladapter,port=1234" ));
		as.start();
		System.out.println( "HelloServer is running" );
	}
}
// http://127.0.0.1:1234
