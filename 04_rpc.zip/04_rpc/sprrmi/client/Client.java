package client;
import org.springframework.context.*;
import org.springframework.context.support.*;
import shared.Hello;
public class Client {
	public static void main(String[] args) throws Exception {
		ApplicationContext bf = new ClassPathXmlApplicationContext(
				"client/beans.xml");
		Hello h = (Hello) bf.getBean("helloservice");
		System.out.println(h.greet(args[0]));
	}
}