package client;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
// import java.rmi.RMISecurityManager;  // deprecated
import java.rmi.RemoteException;
import shared.Hello;
public class Client {
	public static void main(String args[]) throws RemoteException, NotBoundException, MalformedURLException {
		// Deprecated
		// if (System.getSecurityManager() == null)
		// 	System.setSecurityManager(new RMISecurityManager());
		Hello h = (Hello) Naming.lookup("rmi://localhost/HelloServer");  // 1099
		System.out.println(h.greet(args[0]));
	}
}
// java -Djava.security.policy=policy.txt client.Client jack
