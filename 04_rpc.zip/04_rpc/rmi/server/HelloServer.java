package server;
import java.net.MalformedURLException;
import java.rmi.Naming;
// import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import shared.Hello;

class HelloImpl extends UnicastRemoteObject implements Hello {
	public HelloImpl() throws RemoteException {}
	public String greet(String s) throws RemoteException {
		System.out.println("Activation form " + s);
		return "Hello! " + s;
	}
}
public class HelloServer {
	public static void main(String args[]) throws RemoteException, MalformedURLException {
		// if (System.getSecurityManager() == null)
		// 	System.setSecurityManager(new RMISecurityManager());
		Naming.rebind("rmi://localhost/HelloServer", new HelloImpl());
		System.out.println("HelloServer ready.");
	}
}
//	%JAVA_HOME%\jre\lib\security\java.policy
