// ServiceEp.java
package myws;
import javax.xml.ws.Endpoint;
public class ServiceEp {
	public static void main(String[] args) {
		Endpoint ep = Endpoint.publish("http://localhost:8080/hello", new Hello());
		System.out.println("Services start.");
	}
}
