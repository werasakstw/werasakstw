// Hello.java
package myws;
import javax.jws.*;
import javax.jws.soap.SOAPBinding;

@WebService
@SOAPBinding(style=SOAPBinding.Style.RPC)
public class Hello {
	public String greet(String name) {
		return "Hello! " + name + ".";
	}
}