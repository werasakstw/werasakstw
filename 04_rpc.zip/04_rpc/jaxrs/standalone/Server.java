import javax.ws.rs.*;
import com.sun.jersey.api.container.grizzly.GrizzlyServerFactory;
public class Server {
	@Path("myres")
	public static class MyResource {
		@GET	// myres
		public String list() {
			return "list:";
		}
		@GET	// myres/john
		@Path("{id}")
		public String show(@PathParam("id") String id) {
			return "show: " + id;
		}
		@GET	// myres/new
		@Path("new")
		public String _new() {
			return "new:";
		}
		@GET	// myres/john/edit
		@Path("{id}/edit")
		public String edit(@PathParam("id") String id)  {
			return "edit: " + id;
		}
		@POST	// myres
		public String create() {
			return "create:";
		}
		@PUT	// myres/id
		@Path("{id}")
		public String update(@PathParam("id") String id) {
			return "update: " + id;
		}
		@DELETE	// myres/id
		@Path("{id}")
		public String delete(@PathParam("id") String id) {
			return "delete: " + id;
		}
	}
	public static void main(String[] args) throws Exception {
		GrizzlyServerFactory.create("http://localhost:8080");
		System.out.println("Server ready.");
	}
}
// http://localhost:8080/application.wadl
// http://localhost:8080/myres
// http://localhost:8080/myres/john
// http://localhost:8080/myres/new
// http://localhost:8080/myres/jack/edit