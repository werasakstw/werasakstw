import com.sun.jersey.api.client.*;
public class MyClient {
	static String a[] = {
		"http://localhost:8080/myres",
		"http://localhost:8080/myres/john",
		"http://localhost:8080/myres/new",
		"http://localhost:8080/myres/john/edit" };

	public static void main(String[] args) throws Exception {
		Client c = Client.create();
		// list:
		WebResource wr = c.resource("http://localhost:8080/myres");
		System.out.println(wr.get(String.class));

		// show: john
		wr = c.resource("http://localhost:8080/myres/john");
		System.out.println(wr.get(String.class));

		// new:
		wr = c.resource("http://localhost:8080/myres/new");
		System.out.println(wr.get(String.class));

		// edit: john
		wr = c.resource("http://localhost:8080/myres/john/edit");
		System.out.println(wr.get(String.class));

		// create:
		wr = c.resource("http://localhost:8080/myres");
		System.out.println(wr.post(String.class));

		// update: john
		wr = c.resource("http://localhost:8080/myres/john");
		System.out.println(wr.put(String.class));

		// delete: john
		wr = c.resource("http://localhost:8080/myres/john");
		System.out.println(wr.delete(String.class));
	}
}