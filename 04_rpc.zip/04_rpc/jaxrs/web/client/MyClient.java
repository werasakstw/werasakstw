import com.sun.jersey.api.client.*;
public class MyClient {
	public static void main(String[] args) throws Exception {
		Client c = Client.create();
		WebResource r = c.resource("http://localhost:8080/rsApp/jaxrs/greet/" + args[0]);
		System.out.println(r.get(String.class));
	}
}
