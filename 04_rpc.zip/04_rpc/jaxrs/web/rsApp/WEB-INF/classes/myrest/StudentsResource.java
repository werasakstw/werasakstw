// StudentsResource.java
package myrest;
import javax.ws.rs.*;
@Path("/students")
public class StudentsResource {
	@GET
	@Produces("application/xml")
	// http://localhost:8080/rsapp/jaxrs/students
	public String list() {
		return "<students><name>john</name><name>jack</name></students>";
	}

	@GET
	@Path("{name}")
	// http://localhost:8080/rsapp/jaxrs/students/john
	public String get(@PathParam("name") String name) {
		return "get: " + name;
	}

	@POST
	// post, http://localhost:8080/rsapp/jaxrs/students   params=>content
	public String create(@FormParam("id") int id,
			     @FormParam("name") String name,
			     @FormParam("department") String dept){
		return "create: " + id + "," + name + "," + dept;
	}

	@PUT
	@Path("{id}")
	// put, http://localhost:8080/rsapp/jaxrs/1?department=cs
	public String update(@PathParam("id") int id,
			     @FormParam("department") String dept) {
		return "update: " + id + "," + dept;
	}

	@DELETE
	@Path("{id}")
	// delete, http://localhost:8080/rsapp/jaxrs/1
	public String update(@PathParam("id") int id) {
		return "delete: " + id;
	}
}
// http://localhost:8080/rsapp/jaxrs/application.wadl
