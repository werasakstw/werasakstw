// GreetResource.java
package myrest;
import javax.ws.rs.*;
@Path("/greet")
public class GreetResource {
	@GET
	@Path("{name}")
	public String get(@PathParam("name") String name) {
		return "Hello " + name;
	}
}
// http://localhost:8080/rsapp/jaxrs/greet/john

