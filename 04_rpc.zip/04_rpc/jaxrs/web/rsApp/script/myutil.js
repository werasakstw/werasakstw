// myutil.js
var xhr;

function getXhr() {
	if (window.XMLHttpRequest)
		return xhr = new XMLHttpRequest();
	try {
		xhr = new ActiveXObject("Msxml2.XMLHTTP.5.0");
	} catch(e) {
		try {
			xhr = new ActiveXObject("Msxml2.XMLHTTP.4.0");
		} catch(e) {
			try {
				xhr = new ActiveXObject("Microsoft.XMLHTTP");
			} catch(e) {
				throw new Error("create error");
			}
		}
	} 
}
function sendGet(path) {
	getXhr();
	xhr.onreadystatechange = handleStateChange;
	xhr.open("GET", path, true);
	xhr.send(null);
}
function sendPost(path, content) {
	getXhr();
	xhr.onreadystatechange = handleStateChange;
	xhr.open("POST", path, true);
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;");
	xhr.send(content);
}
function handleStateChange() {
	if(xhr.readyState == 4 && xhr.status == 200)
		execute();
}

