package mybeans;
public interface Hello {
	public String greet(String s);
}