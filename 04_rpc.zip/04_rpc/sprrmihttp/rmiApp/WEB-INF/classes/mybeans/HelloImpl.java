package mybeans;
public class HelloImpl implements Hello {
	public String greet(String s) {
		System.out.println("Activation form " + s);
		return "Hello! " + s;
	}
}