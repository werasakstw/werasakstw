package client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import client.mybeans.Hello;
// Deploy rmiApp -> tomcat
class Client {
	public static void main(String[] args) throws Exception {
		ApplicationContext bf = new ClassPathXmlApplicationContext(
					"client/beans.xml");
		Hello h = (Hello) bf.getBean("hello");
		System.out.println(h.greet(args[0]));
	}
}