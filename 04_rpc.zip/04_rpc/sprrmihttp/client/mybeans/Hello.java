package client.mybeans;

public interface Hello {
	public String greet(String name);
}