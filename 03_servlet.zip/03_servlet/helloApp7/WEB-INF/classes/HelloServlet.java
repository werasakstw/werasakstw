import java.io.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException {
		String n = req.getParameter("name");
		PrintWriter pw = res.getWriter();
		pw.println("Hello! " + n);
		pw.close();
	}
}

