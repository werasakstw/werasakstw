import java.io.*;
import java.net.*;

class TunnelClient {
	public static void main(String args[]) throws Exception {
		URL u = new URL("http://localhost:8080/myApp/TunnelServlet");
		URLConnection c = u.openConnection();
		c.setUseCaches(false);
		c.setRequestProperty("CONTENT_TYPE", "text/plain");
		c.setDoInput(true);
		c.setDoOutput(true);
		PrintWriter pw = new PrintWriter(c.getOutputStream());
		pw.print(args[0]);
		pw.close();

		InputStream is = c.getInputStream();
		byte [ ] b = new byte[is.available()];
		is.read(b);
		System.out.println(new String(b));
	}
}	
