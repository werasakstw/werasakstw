import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ReqParamServlet")
public class ReqParamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw = res.getWriter();
		String n[] = req.getParameterValues("name");
		String m = req.getParameter("message");
		pw.println(Arrays.toString(n) + ", " + m);
/*		
		pw.println("<p/>");
		Enumeration<String> e = req.getParameterNames();
		while (e.hasMoreElements()) {
			String name = e.nextElement().toString();
			pw.println(name + " = " + req.getParameter(name) + "<br/>");
		}
*/
		pw.close();
	}
}

