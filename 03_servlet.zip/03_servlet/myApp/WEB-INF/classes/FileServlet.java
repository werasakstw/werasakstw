import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FileServlet")
public class FileServlet extends HttpServlet {
	private byte[] readFile(String fname) throws IOException {
		ServletContext sc = getServletContext();
		InputStream is =  sc.getResourceAsStream("/WEB-INF/data/" + fname);
		byte b[] = new byte[is.available()];
		is.read(b);
		is.close();
		return b;
	}
	private String fileType(String fn) {
		String ex = fn.substring(fn.indexOf("."));
		return (ex.equals("gif"))? "image/gif" : "text/plain";
	}
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String fn = req.getQueryString();
		byte b[] = readFile(fn);
		res.setHeader("Content-type", fileType(fn));
		res.setHeader("Content-Length", b.length + "");
		OutputStream os = res.getOutputStream();
		os.write(b);
		os.close();
	}
}
/*
http://localhost:8080/myApp/FileServlet?hello.txt
http://localhost:8080/myApp/FileServlet?bird.gif
 */

