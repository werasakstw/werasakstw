import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ReqHeaderServlet")
public class ReqHeaderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw = res.getWriter();
		Enumeration<String> e = req.getHeaderNames();
		while (e.hasMoreElements()) {
			String name = e.nextElement().toString();
			pw.println(name + " = " + req.getHeader(name) + "<p/>");
		}
		pw.close();
	}
}

