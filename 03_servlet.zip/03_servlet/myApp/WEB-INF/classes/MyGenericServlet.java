import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/MyGenericServlet")
public class MyGenericServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void service(ServletRequest req, ServletResponse res)
			throws ServletException, IOException {
		PrintWriter pw = res.getWriter();
		pw.println("Hello! I am MyGenericServlet.");     
		pw.close();
	}
}

/* GenericServlet is an abstract class that implements Servlet,
     with only service() unimplemented.

public abstract class javax.servlet.GenericServlet implements javax.servlet.Servlet,javax.servlet.ServletConfig,java.io.Serializable {
  public javax.servlet.GenericServlet();
  public void destroy();
  public java.lang.String getInitParameter(java.lang.String);
  public java.util.Enumeration<java.lang.String> getInitParameterNames();
  public javax.servlet.ServletConfig getServletConfig();
  public javax.servlet.ServletContext getServletContext();
  public java.lang.String getServletInfo();
  public void init(javax.servlet.ServletConfig) throws javax.servlet.ServletException;
  public void init() throws javax.servlet.ServletException;
  public void log(java.lang.String);
  public void log(java.lang.String, java.lang.Throwable);
  public abstract void service(javax.servlet.ServletRequest, javax.servlet.ServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  public java.lang.String getServletName();
}
*/