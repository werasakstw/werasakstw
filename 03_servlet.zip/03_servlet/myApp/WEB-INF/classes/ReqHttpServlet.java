import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ReqHttpServlet/*")
public class ReqHttpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw = res.getWriter();
		pw.println("Protocol: " + req.getProtocol() + "<br/>");
		pw.println("Scheme: " + req.getScheme() + "<br/>");
		pw.println("RemoteHost: " + req.getRemoteHost() + "<br/>");
		pw.println("ServerName: " + req.getServerName() + "<br/>");
		pw.println("ServerPort: " + req.getServerPort() + "<br/>");
		pw.println("PathInfo: " + req.getPathInfo() + "<br/>");
		pw.println("PathTranslated: " + req.getPathTranslated() + "<br/>");
		pw.println("ContextPath: " + req.getContextPath() + "<br/>");
		pw.println("QueryString: " + req.getQueryString() + "<br/>");
		pw.println("RequestURI: " + req.getRequestURI() + "<br/>");
		pw.println("ServletPath: " + req.getServletPath() + "<br/>");
		
	// for POST request
	//	pw.println("ContentType: " + req.getContentType() + "<br/>");
	//	pw.println("ContentLength: " + req.getContentLength() + "<br/>");   
		pw.close();
	}
}
// http://localhost:8080/myApp/ReqHttpServlet/mypathinfo?myquerystring
