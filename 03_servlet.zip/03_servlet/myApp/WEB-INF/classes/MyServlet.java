import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet(urlPatterns={"/MyServlet", "/my"})
public class MyServlet implements Servlet {
	private ServletConfig sc;
	public void init(ServletConfig sc) { this.sc = sc; } 
	public void service(ServletRequest req, ServletResponse res)
			throws ServletException, IOException {
		PrintWriter pw = res.getWriter();
		pw.println("Hello! I am MyServlet.");
		pw.close();  
	}
	public String getServletInfo() { return "MyServlet"; }
	public ServletConfig getServletConfig() { return sc; }
	public void destroy() { }
}
/* Servelt is an interface.
A servlet class must be public.

A servlet may be deployed with multiple paths.
	http://localhost:8080/myApp/MyServlet
	http://localhost:8080/myApp/my
*/