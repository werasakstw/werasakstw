import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyHttpServlet")
public class MyHttpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.getWriter().println("That was a GET");   
	}
	@Override
	public void doPut(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.getWriter().println("That was a PUT");     
	}
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.getWriter().println("That was a POST");     
	}
	@Override
	public void doDelete(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.getWriter().println("That was a Delete");     
	}
}
/* HttpServlet extends GenericServlet has doXXX method to handle 
 GET, POST, PUT, DELETE, HEAD, OPTIONS, and TRACE of http requests.
But most browsers handle only GET and POST.

public abstract class javax.servlet.http.HttpServlet extends javax.servlet.GenericServlet {
  public javax.servlet.http.HttpServlet();
  protected void doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  protected long getLastModified(javax.servlet.http.HttpServletRequest);
  protected void doHead(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  protected void doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  protected void doPut(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  protected void doDelete(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  protected void doOptions(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  protected void doTrace(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  protected void service(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  public void service(javax.servlet.ServletRequest, javax.servlet.ServletResponse) throws javax.servlet.ServletException, java.io.IOException;
  static {};
}
*/
