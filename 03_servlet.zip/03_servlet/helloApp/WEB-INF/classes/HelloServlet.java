import java.io.*;
import javax.servlet.http.*;
public class HelloServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException {
		String n = req.getParameter("name");
		PrintWriter pw = res.getWriter();
		pw.println("Hello! " + n);
		pw.close();
	}
}

