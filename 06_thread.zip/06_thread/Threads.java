import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* When the JVM is started. a thread named "main" is created.
When the first class of an app is loaded, the "main" thread
executes its main(). */
class MainThread {
// class Threads {
	public static void main(String args[]) {
		Thread t = Thread.currentThread();
		// returns the thread that executes this statement.
		System.out.println(t.getName());
	}
}

/* There are many ways to create and use thread:
1. Subclassing Thread  */
class MyThread extends Thread {
	MyThread(String n) { super(n); }
	public void run() {
		for (int i =0; i < 100; i++)
			System.out.print(Thread.currentThread().getName());
	}
}
class MyThreadTest {
// class Threads {
	public static void main(String args[]) {
		Thread a = new MyThread("A");
		Thread b = new MyThread("B");
		a.start();
		b.start();
		// b.run();
		System.out.println("main stops");
	}
}

/* 2. Implementing Runnable.
Subclassing has more overhead than implementing interface. */
class MyRunnable implements Runnable {
	public void run() {
		for(int i = 0; i < 100; i++)
			System.out.print(Thread.currentThread().getName());
	}
}
class MyRunnableTest {
// class Threads {
	public static void main(String args[]) {
		new Thread(new MyRunnable(), "A").start();
	}
}

/* 3. Using Anonymous Class.
Mostly we use a thread only once, the class object should be garbage collected. */
class AnonymousTest {
// class Threads {
	public static void main(String args[]) {
		new Thread(new Runnable(){
			public void run() {
				for(int i = 0; i < 100; i++)
					System.out.print(Thread.currentThread().getName());
			}
		}, "A").start();
	}
}

// 4. Using Lambda.
class LambdaTest {
// class Threads {
	public static void main(String args[]) {
		new Thread(() -> {
				for(int i = 0; i < 100; i++)
					System.out.print(Thread.currentThread().getName());
		}, "A").start();
	}
}

// 5. Using Thread Pool.
class LambdaTest {
// class Threads {
	public static void main(String args[]) {
		ExecutorService es = Executors.newFixedThreadPool(10);
		es.execute(() -> {
			for(int i = 0; i < 100; i++)
				System.out.print(Thread.currentThread().getName());
		});
		es.shutdown();
	}
}
