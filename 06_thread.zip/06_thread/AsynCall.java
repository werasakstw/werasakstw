import java.util.concurrent.*;
import java.util.function.Supplier;

/* Java 7:
A callable is an instance that can be executed by a future task.
A FutureTask provides asynchronous calls. While a future task is
 executed by the created thread, the caller thread may continue
 working on something and repeatedly checks for the result. */
class MyCallable implements Callable<String> {
	public String call() throws Exception {
		Thread.sleep(500);
		return "Finish by: " + Thread.currentThread().getName();
	}
}
class AsynJava7 {
// class AsynCall {
	public static void main(String[] args) {
		// Wrap MyCallable in a FutureTask.
		FutureTask<String> fc = new FutureTask<>(new MyCallable());
		// Create a thread to execute the FutureTask.
		new Thread(fc).start();
		// Repeatedly check and wait for the result, if it is done get it.
		while (true) {
			try {
				if(fc.isDone()){
					System.out.print(fc.get());  // get the result returned by the future task
					break;
				}
				System.out.println("Doing something...");
				Thread.sleep(100);
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}
		}
	}
}

/* Java 8: CompletableFuture simplify asynchronous call and
 getting the result.
	It executes a lambda instead of a callable.
	A worker thread is created explicitly.
	No loop for checking the result. */

class AsynJava8 {
// class AsynCall {
	public static void main(String[] args) throws InterruptedException, ExecutionException, TimeoutException {
		CompletableFuture<String> cf = CompletableFuture.supplyAsync( // Supplier<String>
			() -> {
				for (int i = 0; i < 3; i++) {
					System.out.println("running... " + Thread.currentThread().getName());
					try { Thread.sleep(500); } catch(Exception ex) { }
				}
				return "Finish by: " + Thread.currentThread().getName();
			});

		// getNow(<fallback>): if the result is not present yet, the fallback value is returned.
		System.out.println("getNow:  " + cf.getNow("Hi"));

		// get(<time>, <time uint>): waits x time units, then tries to get the result,
		// if no value, a TimeoutException is thrown.
		try {
			System.out.println("get 1: " + cf.get(1, TimeUnit.SECONDS ) );
		} catch(TimeoutException ex) {
			System.out.println("get 1: Timeout");
		}
		System.out.println("get 5: " + cf.get(5, TimeUnit.SECONDS ) );

		// get() waits for ever until the CompletableFuture is completed or cancelled.
		System.out.println("get:  " + cf.get());
	}
}
