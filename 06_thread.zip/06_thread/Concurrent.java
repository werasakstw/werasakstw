/* Concurrent means there are more than one threads execute
 a function or block at the same time.
Java provides 'synchronized' to enforce single thread to be
 executed in the function or block. */
class A {
	 // synchronized
	 void f() {
		 String t = Thread.currentThread().getName();
		 System.out.println(t + ": " + "enter f()");
		 try { Thread.sleep(1000); } catch(Exception e) { }
		 System.out.println(t + ": " + "leaving f()");
	 }
 }
 class ConcurrentTest {
// class Concurrent {
	public static void main(String agrs[]) {
		A a = new A();
		Runnable r = () -> { a.f(); };
		new Thread(r, "A").start();
		new Thread(r, "B").start();
	}
}

// Thread unsafe is undesirable results from allowing concurrent.
class Counter {
	long x = 0;
	void inc() { ++x; }
	// synchronized void inc() { ++x; }
}
class UnSafe {
// class Concurrent {
	public static void main(String args[]) {
		Counter c = new Counter();
		Runnable r = () -> { c.inc(); };
		for (int i = 0; i < 10000; i++)
			new Thread(r).start();
		try { Thread.sleep(100); } catch(Exception e) { }
		System.out.println(c.x);
	}
}

// Data Corruption is a kind of unsafe that results as invalid data.
class Student {
	String first, last;
	// synchronized public void setName(String first, String last) {
	public void setName(String first, String last) {
		this.first = first;
		if (first.equals("John"))
			try { Thread.sleep(100); } catch(Exception e) { }
		this.last = last;
	}
}
class Corrupt {
// class Concurrent {
	public static void main(String agrs[]) {
		Student s = new Student();
		new Thread(() -> { s.setName("John", "Rambo"); }).start();
		new Thread(() -> { s.setName("Jack", "Ripper"); }).start();
		try { Thread.sleep(300); } catch(Exception e) { }
		System.out.println(s.first + ", " + s.last);
	}
}
//----------------------------------------------------
class MyUtil {
	public static void run(String n) {
		String t = Thread.currentThread().getName();
		System.out.println(t + ": " + "enter " + n);
		try { Thread.sleep(1000); } catch(Exception e) { }
		System.out.println(t + ": " + "leaving " + n);
	}
}
/* If threads perform read-only there should be no problems.
But if threads perform any write, thread unsafe may happen
 we must prevent with locking(using 'synchronized').
There are two kinds of locking.
1. Instance Lock. */
class B {
	synchronized public void f() { MyUtil.run("f()"); }
	synchronized public void g() { MyUtil.run("g()"); }
}
class InstanceLock {
// class Concurrent {
	public static void main(String args[]) {
		B b1 = new B();
		B b2 = new B();
		new Thread(() -> { b1.f();}, "A").start();
		new Thread(() -> {
				b1.f();
				// b1.g();
			}, "B1").start();
		new Thread(() -> {
				b2.f();
				// b2.g();
			}, "B2").start();
	}
}

// 2. Class Lock.
class C {
	synchronized public static void f() { MyUtil.run("f()");	}
}
class ClassLock {
// class Concurrent {
	public static void main(String args[]) {
		C c1 = new C();
		C c2 = new C();
		new Thread(() -> { c1.f(); }, "C1").start();
		new Thread(() -> { c2.f(); }, "C2").start();
	}
}

//----------------------------------------------------

/* Java provides two sides of locking:
1. Callee lock: happen at the called method which locks
  the whole method. */
class D {
	// Callee Lock.
	synchronized public void f() { MyUtil.run("f()"); }

	// Class/Object Lock.
	public void g() { synchronized(MyUtil.class) { MyUtil.run("g()"); } }

	// Caller Lock.
	public void h() { MyUtil.run("h()"); }
}
class LockTest {
// class Concurrent {
	public static void main(String args[]) {
		D d = new D();
		d.f();
		d.g();
		synchronized(d) { d.h(); }
	}
}
