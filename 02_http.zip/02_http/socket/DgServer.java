import java.net.*;

class DgServer {
	public static void main(String args[]) throws Exception {
		DatagramSocket ds = new DatagramSocket(12345);
		System.out.println("Server created.");
		while(true) {
			DatagramPacket dp = new DatagramPacket(new byte[100], 100);
			ds.receive(dp);
			String msg = new String(dp.getData()).trim();
			if (msg.equals("quit"))
				break;
			String header =
				"\nFrom Host: " + dp.getAddress() +
				"\nLength: " + dp.getLength() +
				"\nContent:\n";
			System.out.println(header + msg);
		}
		ds.close();
	}
}
