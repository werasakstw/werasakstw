import java.io.*;
import java.net.*;

class ThreadConServer {
	static class MyRunnable implements Runnable {
		Socket s;
		MyRunnable(Socket s) { this.s = s; }
		public void run() {
			try (
				PrintStream op = new PrintStream(s.getOutputStream());
			) {
				op.println("Hello!");
				Thread.sleep(2000);
				s.close();
			} catch(Exception e) {
				System.out.println(e);
			}

		}
	}
	public static void main(String args[]) throws Exception {
		ServerSocket ss = new ServerSocket(12345, 3);
		System.out.println("Server created.");
		while (true) {
			new Thread(new MyRunnable(ss.accept())).start();
			if (Thread.interrupted())
				break;
		}
		ss.close();
	}
}
