import java.io.*;
import java.net.*;

class ConClient {
	static class ClientRunnable implements Runnable {
		private int n;
		ClientRunnable(int n) { this.n = n; }
		public void run() {
			try (
				Socket s = new Socket("localhost", 12345);
				BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			) {
				System.out.println(n + ", " + br.readLine());
			} catch(Exception e) {
				System.out.println(n + ": " + e.getMessage());
			}
		}
	}
	public static void main(String args[]) throws Exception {
		for (int i = 0; i < 10; i++)
			new Thread(new ClientRunnable(i)).start();
	}
}
