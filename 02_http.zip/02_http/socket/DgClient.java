import java.net.*;

class DgClient {
	public static void main(String args[]) throws Exception {
		String msg = "Hello how are you?";
		byte b[] = msg.getBytes();
		byte a[] = {(byte)127, (byte)0, (byte)0, (byte)1};
		DatagramPacket dp = new DatagramPacket(b, b.length, InetAddress.getByAddress(a), 12345);
		DatagramSocket ds = new DatagramSocket();
		ds.send(dp);
		System.out.println("Send packet.");
		ds.close();
	}
}
