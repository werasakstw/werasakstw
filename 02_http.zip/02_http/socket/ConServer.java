import java.io.*;
import java.net.*;

class ConServer {
	public static void main(String args[]) throws Exception {
		ServerSocket ss = new ServerSocket(12345, 3);
		System.out.println("Server created.");
		while (true) {
				Socket s = ss.accept();
				PrintStream op = new PrintStream(s.getOutputStream());
				op.println("Hello!");
				Thread.sleep(4000);
				s.close();
				op.close();
				if (Thread.interrupted())
					break;
			}
		ss.close();
	}
}
