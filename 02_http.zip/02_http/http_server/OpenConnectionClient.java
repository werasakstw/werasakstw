import java.io.*;
import java.net.*;
import java.util.*;

class OpenConnectionClient {
	public static void main(String[] args) throws Exception {
 		URL u = new URL("http://127.0.0.1:8080/tomcat.svg");
		URLConnection c = u.openConnection();
		System.out.println("Content-type: " + c.getContentType());
		System.out.println("Content-length: " + c.getContentLength());
		System.out.println("Content-encoding: " + c.getContentEncoding());
		System.out.println("Date: " + new Date(c.getDate()));
		System.out.println("Expiration date: " + new Date(c.getExpiration()));
		System.out.println("Last modified: " + new Date(c.getLastModified()));

		c.connect();
		try (
			InputStream is = c.getInputStream();
			FileOutputStream fo = new FileOutputStream("t.svg");
		) {
			int n = 0;
			byte b[] = new byte[1024];
			while ((n = is.read(b)) != -1)
				fo.write(b, 0, n);
		}
	}
}
