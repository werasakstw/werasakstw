import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.HttpEntity;
import org.apache.http.util.EntityUtils;
import org.apache.http.entity.StringEntity;

class Client {  // Using SunHttpServer
	public final static void main(String[] args) throws Exception {
		HttpClient hc = new DefaultHttpClient();
//		HttpPost hp = new HttpPost("http://localhost:8080/hello");
		HttpPost hp = new HttpPost("http://localhost:8080/hi");
		hp.setEntity(new StringEntity("john"));
		HttpEntity he = hc.execute(hp).getEntity();
		System.out.println(EntityUtils.toString(he));
	}
}
