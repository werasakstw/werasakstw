import java.net.MalformedURLException;
import java.net.URL;

class URLTest {
	public static void main(String[] args) {
		try {
			URL u = new URL("http://www.mycomp.com/hello.html");
			System.out.println(u);

			u = new URL("http", "www.mycomp.com", "/hello.html");
			System.out.println(u);

			u = new URL("http", "www.mycomp.com", 8080, "/myapp/hello.html?a=1&b=2");
			System.out.println(u);
			System.out.println("protocol: " + u.getProtocol());
			System.out.println("host: " + u.getHost());
			System.out.println("port: " + u.getPort());
			System.out.println("path: " + u.getPath());
			System.out.println("query: " + u.getQuery());
		} catch (MalformedURLException e) {
			System.out.println(e);
		}
	}
}
