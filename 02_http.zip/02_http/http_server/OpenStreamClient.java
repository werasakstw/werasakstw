import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

class OpenStreamClient {
	public static void main(String[] args) throws MalformedURLException {
		URL u = new URL("http://localhost:8080/index.jsp"); // Tomcat
		// URL u = new URL("http://google.com/index.html");
		try ( // URL is not autoclosable.
			InputStream is = u.openStream();
			BufferedReader br = new BufferedReader (new InputStreamReader(is));
		){
			String s;
			while ((s = br.readLine()) != null)
				System.out.println(s);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
