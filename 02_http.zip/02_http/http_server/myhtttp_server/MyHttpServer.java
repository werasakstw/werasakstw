import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

class MyHttpServer {
	public static void main(String args[]) throws IOException {
		ServerSocket ss = new ServerSocket(8080);
		System.out.println("Server created.");
		while (true) {
			(new Thread(new MyRunnable(ss.accept()))).start();
			if (Thread.interrupted()) {
				ss.close();
				break;
			}
		}
	}
}
class MyRunnable implements Runnable {
	private Socket s;
	MyRunnable(Socket s) { this.s = s; }
	public void run() {
		try (
			BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			PrintStream ps = new PrintStream(s.getOutputStream());
		){
			String r = br.readLine();
			if (r.indexOf("GET / ") != -1) {
				byte b[] = FileUtil.readFile("index.html");
				ps.print("HTTP/1.1 200 OK\r\n");
				ps.print("Content-length: "+ b.length + "\r\n");
				ps.print("Content-type: text/html\r\n\r\n");
				ps.write(b);
			}
			s.close();
		} catch(Exception e) {
			System.out.println(e);
		}
	}
}
