import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
class MyHttpClient {
	public static void main(String args[]) {
		try (
			// Socket s = new Socket("google.com", 80);
			Socket s = new Socket("localhost", 8080);
			PrintStream ps = new PrintStream(s.getOutputStream());
		) {
			ps.println("GET / HTTP/1.1");
			ps.println("Accept: */*");
			ps.println("User-Agent: HttpTest");
			ps.println("Host: localhost");
			ps.println();
			BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			String l;
			while ((l = br.readLine()) != null)
				System.out.println(l);
		} catch(Exception e) {
			System.out.println(e);
		}
	}
}
/*		http://127.0.0.1:8080
	curl 127.0.0.1:8080
	curl -verbose 127.0.0.1:8080
*/
