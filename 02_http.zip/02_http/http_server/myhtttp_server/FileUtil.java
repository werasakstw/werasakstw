import java.io.FileInputStream;
public class FileUtil {
	public static byte [] readFile(String name) throws Exception {
		try (
			FileInputStream fis = new FileInputStream(name);
		){
			int n = fis.available();
			byte [] b = new byte[n];
			fis.read(b, 0, n);
			return b;
		} catch (Exception e) {
			throw e;
		}
	}
}
