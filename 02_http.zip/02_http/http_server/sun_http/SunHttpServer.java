import com.sun.net.httpserver.*;
import java.net.*;
import java.io.*;

class SunHttpServer {
	public static void main(String args[]) throws Exception {
		HttpServer hs = HttpServer.create(new InetSocketAddress(8080), 1);
		// Context Dispatching
		hs.createContext("/hello", new HelloHandler());
		hs.createContext("/hi", new HiHandler());
		hs.start();
		System.out.println("Server started at 127.0.0.1:8080");
	}
}
// Client-Server communicate via stream.
class MyHandlerUtil {
	public String inputName(HttpExchange he) throws IOException {
		InputStream is = he.getRequestBody();
		BufferedReader br = new BufferedReader(
			new InputStreamReader(is));
		String name = br.readLine();
		br.close();
		return name;
	}
	public void outputResponce(HttpExchange he, String res) throws IOException {
		he.sendResponseHeaders(200, res.length());
		OutputStream os = he.getResponseBody();
		os.write(res.getBytes());
		os.close();
	}
}

class HelloHandler extends MyHandlerUtil implements HttpHandler {
	public void handle(HttpExchange he) throws IOException {
   	String res = "Hello " + inputName(he);
		outputResponce(he, res);
		he.close();
	}
}
class HiHandler extends MyHandlerUtil implements HttpHandler {
	public void handle(HttpExchange he) throws IOException {
   	String res = "Hi " + inputName(he);
		outputResponce(he, res);
		he.close();
	}
}
