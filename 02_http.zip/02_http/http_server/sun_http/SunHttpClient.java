import java.io.*;
import java.net.*;

class SunHttpClient {
	public static void main(String[] args) {
		// Connect
		URLConnection uc = null;
		try {
			URL u = new URL("http://localhost:8080/hello");
			// URL u = new URL("http://localhost:8080/hi");
			uc = u.openConnection();
			uc.setDoInput(true);
			uc.setDoOutput(true);
			uc.connect();
		} catch(Exception e) {
			System.out.println("Connect error: " + e);
		}

		// Output (client side)
		try (
			PrintStream ps = new PrintStream(uc.getOutputStream());
		) {
			ps.println("John");
		} catch(Exception e) {
			System.out.println("Output error: " + e);
		}

		// Input (client side)
		try (
			InputStream is = uc.getInputStream();
			BufferedReader br = new BufferedReader(
				new InputStreamReader(is));
		) {
			System.out.println(br.readLine());
		} catch(Exception e) {
			System.out.println("Input error: " + e);
		}
	}
}
