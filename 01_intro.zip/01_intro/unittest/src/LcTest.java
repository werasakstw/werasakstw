import org.junit.*;
import beans.Hello;

public class LcTest {
	private Hello h;
	@Before
	public void setUp() {
		h = new Hello();
		System.out.println("setUp");
	}
	@After
	public void tearDown() {
		h = null;
		System.out.println("tearDown");
	}
	@Test
	public void test1() {
		System.out.println(h.greet("John Bimbo"));
		// System.out.println(h.greet("John Rambo"));
	}
	@Test
	public void test2() {
		System.out.println(h.greet("Jack Ripper"));
	}
	@Test
	public void test3() {
		System.out.println(h.greet("Jame Bond"));
	}
}