import org.junit.runner.JUnitCore;

public class HelloMain {
	public static void main(String args[]) {
		JUnitCore.main("HelloTest");

		// JUnitCore.runClasses(HelloTest.class);
	
		// Class c[] = { HelloTest.class, HelloTest.class };
		// new JUnitCore().run(c);
	}
}