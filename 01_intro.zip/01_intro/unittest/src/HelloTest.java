import org.junit.*;
import beans.Hello;

public class HelloTest {
	Hello h = new Hello();

	@Test
	public void test1() {
		System.out.println(h.greet("Jack Ripper"));
	}

	@Test (expected=RuntimeException.class)
	// @Test
	public void test2() {
		System.out.println(h.greet("John Rambo"));
	}

	@Ignore @Test
	public void test3() {
		System.out.println(h.greet("Ignore"));
	}
}