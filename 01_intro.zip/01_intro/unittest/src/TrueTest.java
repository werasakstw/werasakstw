import org.junit.*;
import static org.junit.Assert.*;
import beans.Hello;

public class TrueTest {
	private Hello h = new Hello();
	@Test
	public void test1() {
		assertTrue(h.greet("John Bimbo").equals("Hello! John Bimbo"));
	}
	@Test
	public void test2() {
		assertTrue(h.greet("Jack Ripper").equals("Hello! Jack Ripper"));
	}
	@Test
	public void test3() {
		assertTrue(h.greet("Jame Bond").equals("Hello! Jame Bond"));
	}
}