import org.junit.*;
import beans.Hello;

public class LcClassTest {
	static private Hello h;

	@BeforeClass
	static public void start() {
		h = new Hello();
		System.out.println("start");
	}
	@AfterClass
	static public void stop() {
		h = null;
		System.out.println("stop");
	}
	@Test
	public void test1() {
		System.out.println(h.greet("John Bimbo"));
	}
	@Test
	public void test2() {
		System.out.println(h.greet("Jack Ripper"));
	}
	@Test
	public void test3() {
		System.out.println(h.greet("Jame Bond"));
	}
}