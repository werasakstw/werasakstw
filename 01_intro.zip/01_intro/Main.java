/* The class that will be executed by the java.exe
     must have a public static void main().
main() cannot return anything, even a null.
main() must has 'String[] args' as parameter.
main() can be overloaded, but the other versions
 must be explicitly called.

'java.exe' start the JVM, load the first class and executes
  main() of the class (without creating object of the class,
  that means main() must be 'static').
*/
class Main {
    public static void main(String[] args) {
        System.out.println("Hello");
        // return null;
    }
    public static void main() {
        System.out.println("main");
    }
    public static void Main(String[] args) {
      System.out.println("Main");
   }
}
