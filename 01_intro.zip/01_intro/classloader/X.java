/* There can be at most one public class in a file.
The public class name must be the same as the file name.

At runtime if the 'class loader'
 can not find Y.class, a NoClassDefFoundError is throwed.

At compile time if the 'class loader'
  - find Y.class it is loaded normally.
  - find Y.java but not Y.class, Y.java is compiled and loaded.
  - find Y.java and Y.class, if uptodate Y.class is loaded else
     Y.java is compiled and loaded.
*/
public class X {
    public static void main(String[] args) {
       (new Y()).print();
    }
}
