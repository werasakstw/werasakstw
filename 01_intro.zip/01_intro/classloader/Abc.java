class A { }
class B { }
class C { }
public class Abc {
	public static void main(String args[]) {
		A a;		// lazy
		new B();	// B is loaded.
	}
}
/* A Java application is a set of classes with a class
that has main() as the starting point.

When a class name is found for the first time,
the 'class loader' is asked to load the class.
  - compile time: the class information is used for error checking.
  - execution time: the class is used for create objects.

C++ compiles and links all classes into an executable file
  that will be loaded as a whole when executed.
Java compiles each classes into separate files then loads
  as needed when execute.

The 'class loader' creates a 'class object' for each class and
stores stores in a HashTable.
All classes are loaded only once at the first encounter.
Class objects cannot be programmatically unloaded.
*/
