class Y {
	public void print() {
      System.out.println("Y");
   }
}
