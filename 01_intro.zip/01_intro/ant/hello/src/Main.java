import beans.Hello;

public class Main {
	public static void main(String[] args) {
		new Hello().hello();
	}
}
/* Command line:
1. Create jar file.
jar -cf m.jar beans\*.class
jar -tf m.jar

2. Set CLASSPATH
set CLASSPATH=m.jar;.

3. Run Main
rename \beans
java Main

-----------------------------------------

Application in jar.
Create manifest file m.txt.
jar -cfm m.jar m.txt .
java -jar m.jar
*/
