package beans;
public interface Hello {
	public String greet(String name);
}