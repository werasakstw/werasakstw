package beans;
public class HelloBean implements Hello {
	public String greet(String name) {
		return "Hello! " + name;
	}
}