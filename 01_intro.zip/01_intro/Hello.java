class Hello {
	public static void main(String[] args) {
		System.out.print("Hello");
	}
}
/*
1. Set Env: systempropertiesadvanced.exe
		JAVA_HOME
		%JAVA_HOME%\bin

2. Command line:
cd C:\myjava\01_intro
javac Hello.java
java Hello

java12: set18.bat
java Hello.java

3. Atom:
Package -> Settings View -> Install Packages/Themes
			atom-shell-commands
 https://atom.io/packages/atom-shell-commands
File -> Config
........
    commands: [
	 {
	   name: "compile java"
	   command: "javac"
	   arguments: [ "{FileName}" ]
	   options:
	 	 cwd: "{FileDir}"
	 	 keymap: "alt-1"
	 }
	 {
	   name: "run java"
	   command: "java"
	   arguments: [ "{FileNameNoExt}" ]
	   options:
	 	 cwd: "{FileDir}"
	 	 keymap: "alt-2"
	 }
 ]
*/
