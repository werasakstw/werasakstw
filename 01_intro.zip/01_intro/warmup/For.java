import java.util.*;

class For {
	public static void main(String args[]) {
		String s[] = { "John", "Jack", "Joe", "Jim" };

		// Old For-Loop.
		for (int i = 0; i < s.length; i++)
			System.out.print(s[i] + ", ");
		System.out.println();

		// Java 5 Fast For-Loop.
		for (String x : s)
			System.out.print(x + ", ");
		System.out.println();

		// All collections can be iterated by fast for-loop.
		List<String> ls = new ArrayList<String>(Arrays.asList(s));
		for (String x : ls)
			System.out.print(x + ", ");
	}
}
