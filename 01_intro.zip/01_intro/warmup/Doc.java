public class Doc {
	/**
	 * @version 1.0
	 * @author John Rambo
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		System.out.println("Hello!");
	}

}
/*    javadoc -d doc Doc.java
The result is \doc in working directory.
*/