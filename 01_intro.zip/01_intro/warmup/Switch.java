class Switch {
	public static void main(String args[]) {
	/* Java7 allows String to be a switcher in Switch Statements.
	Strings in cases must be literals, not references.
 	No duplicate and null cases. */
		String s = "hello";
		switch (s) {
			case "hello": System.out.println("Hello how do you do?");
				break;
			case "hi": System.out.println("Hi what's up?");
				break;
			default: System.out.println("Invalid.");
		}

	/* Java11 allows switch expression.
		int n = 5;
		String ns = switch(n) {
			case 0 -> "zero";
			case 1 -> "one";
			case 2, 3 -> "few";
			default -> "many";
		};
		System.out.println(ns);  */
	}
}
/* Before Java 18, switch expression was a preview feature.
javac -source 18 --enable-preview Switch.java
java --enable-preview Switch
*/
