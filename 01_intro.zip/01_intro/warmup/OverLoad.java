class OverLoad {
	static class A {
		void f() { }
		void f(int x) { }
		// int  f(int x) { }   // Return type is not concerned.
		void f(char c, double d) { }
		void f(double d, char c) { }
	}
	public static void main(String args[]) {
		A a = new A();
		a.f();
		a.f(1);
		a.f('a', 1.0);
		a.f(1.0, 'a');
	}
}