/* javap java.lang.System
   javap java.io.PrintStream   */
import java.util.Date;

class Print {
	public static void main(String args[]) {
		/* print() and println() are overloaded for all simple types
		    String and Object.
		If the parameter is Object, toString() is called. */
		System.out.println(new Date());

		// If the parameter is expression, it is evaluated and toString().
		System.out.println(1+2);
	}
}
