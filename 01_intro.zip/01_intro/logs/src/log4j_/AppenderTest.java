package log4j_;
import org.apache.log4j.*;
import java.io.*;
import java.util.Date;

class AppenderTest {
	public static void main(String args[]) throws IOException {
		Logger a = Logger.getLogger("A");
		FileAppender fa = new FileAppender(
			new SimpleLayout(),	// layout
			"a.log",			// file name
			false);				// append mode
		a.addAppender(fa);
		a.info("Hello!");
		
		Logger b = Logger.getLogger("B");
		RollingFileAppender rfa = new RollingFileAppender(
			new SimpleLayout(), "b.log", true);
		b.addAppender(rfa);
		b.info("Hello!");
		rfa.rollOver();
		b.info("Hi!");
		
		Logger c = Logger.getLogger("C");
		DailyRollingFileAppender drf = new DailyRollingFileAppender(
			new SimpleLayout(), "c.log", "yyyy-MM-dd");
						                // date pattern
		c.addAppender(drf);
		c.info("Hello! " + new Date());
	} // The result is in ...\logs
}