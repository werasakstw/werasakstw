package log4j_;
import org.apache.log4j.*;

class Levels {
	public static void main(String args[]) {
		Logger a = Logger.getLogger("A");
//		a.setLevel(Level.WARN);
		
		a.log(Level.OFF, "OFF");
		a.log(Level.FATAL, "FATAL");
		a.log(Level.ERROR, "ERROR");
		a.log(Level.WARN, "WARN");
		a.log(Level.INFO, "INFO");
		a.log(Level.DEBUG, "DEBUG");
		a.log(Level.ALL, "ALL");

		a.fatal("fatal");
		a.error("error");
		a.warn("warn");
		a.info("info");
		a.debug("debug");
	}
}