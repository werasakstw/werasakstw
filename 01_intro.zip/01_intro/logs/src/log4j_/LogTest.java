package log4j_;
import org.apache.log4j.*;
//import org.apache.log4j.lf5.*;

class LogTest {
	public static void main(String args[]) throws Exception {
//		BasicConfigurator.configure();
//		DefaultLF5Configurator.configure();
/* If not defined the log4j.properties in CLASSPATH is used.
	the project's src is in CLASSPATH.  */

		Logger l = Logger.getLogger("A");
		l.info("Hello!");
		l.info("Hello! again");
	}
}
