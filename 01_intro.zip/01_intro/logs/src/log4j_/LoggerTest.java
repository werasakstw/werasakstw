package log4j_;
import org.apache.log4j.*;

class LoggerTest {
	public static void main(String args[]) {
		Logger l1 = Logger.getLogger(LoggerTest.class);
		Logger l2 = Logger.getLogger("LoggerTest");
		l1.info("Hello!");
		l2.info("Hi!");
		System.out.println(l1 == l2);
	}
}
