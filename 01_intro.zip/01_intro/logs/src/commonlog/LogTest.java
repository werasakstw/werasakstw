package commonlog;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class LogTest {
	public static void main(String args[]) {
		Log l = LogFactory.getLog("A");
		System.out.println(l.getClass().getName());
	}
}
/*
LogFactory looks for the system property "org.apache.commons.logging.Log"
   If there is no such system property
	  the factory tries to load Log4J�s Logger
   If Log4J can�t be loaded
	  the factory tries to load the JDK 1.4�s logging
   If JDK 1.4�s logging can�t be loaded
	  the factory tries to JDK 1.3�s logging class (Jdk13LumberjackLogger)
   Finally, if all fails
	  the factory uses the SimpleLog class

Try: Include in CLASSPATH:
   - commons-logging-1.1.jar only
   - commons-logging-1.1.jar and log4j-1.2.8.jar
*/