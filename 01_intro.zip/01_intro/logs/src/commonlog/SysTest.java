package commonlog;
import org.apache.commons.logging.*;

class SysTest {
	public static void main(String args[]) {
		// Explicitly specify which lib the be used.
		System.setProperty( "org.apache.commons.logging.Log",
			"org.apache.commons.logging.impl.Log4JLogger" );
//		 	"org.apache.commons.logging.impl.Jdk14Logger" );
                  	
		Log l = LogFactory.getLog("A");
		System.out.println(l.getClass().getName());
		l.info("Hello");
	}
}
