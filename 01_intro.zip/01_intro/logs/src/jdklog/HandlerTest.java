package jdklog;
import java.util.logging.*;

class HandlerTest {
	public static void main(String argv[]) throws Exception {
		Logger l = Logger.getLogger("global");
		Handler h = new FileHandler("mylog.xml");
		l.addHandler(h);
		l.info("hello");
		l.info("bye");
	}
} // The result is in ....\logs.
