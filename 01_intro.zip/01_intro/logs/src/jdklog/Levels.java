package jdklog;
import java.util.logging.*;

class Levels {
	public static void main(String argv[]) throws Exception {
		Logger l = Logger.getLogger("global");
//		l.setLevel(Level.WARNING);
//		l.setLevel(Level.OFF);
		
		l.severe("severe");   	// highest
		l.warning("warning");
		l.info("info");
		l.config("config");
		l.fine("fine");
		l.finer("finer");
		l.finest("finest");		// lowest 
	}
}

