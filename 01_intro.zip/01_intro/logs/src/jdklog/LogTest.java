package jdklog;
import java.util.logging.*;

class LogTest {
	public static void main(String argv[]){
		Logger l = Logger.getAnonymousLogger();
		// Logger l = Logger.getLogger("global");
		// Logger l = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
		// Logger l = Logger.getLogger(LogTest.class.getName());

		l.log(Level.INFO, "info");
		l.info("info again");
	}
}
