import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import beans.Hello;

public class Main {
	public static void main(String[] args) throws Exception {
		ApplicationContext bf = new ClassPathXmlApplicationContext(
				"beans/beans.xml");
		Hello h = (Hello) bf.getBean("hello");
		System.out.println(h.greet("john"));
	}
}