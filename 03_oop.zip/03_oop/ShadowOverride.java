/* Shadow: A child class has data members with the same name as
    data members in parent class. Type and value may be different.
 Override: A child class has method members with the same header as
	 method members in parent class. Body may be different.*/
class A {
	int x = 1;
	void f() { System.out.println("A"); }
}
/* @Override tells the compiler to enforce the correctness
 of overriding for the method. */
class B extends A {
	float x = 2.0f;							   // shadow
	@Override
	void f() { System.out.println("B"); }	// override
}
class ShadowOverride {
	public static void main(String args[]) {
		B b = new B();
		System.out.println(b.x);
		b.f();
	}
}
//------------------------------------------------

/* Access privileges:
 			private < default < protected < public    */
class C {
	int x = 1;
	void f() { System.out.println("C"); }
}
class E extends C {
	// Shadowing with less or more privileges are allowed.
	private float x = 2.0f;
	// public double x = 3.0;			// Ok

	// Overriding must have equal or more access privileges.
	// private void f() { System.out.println("E"); }	// error
	public void f() { System.out.println("E"); }
}
//---------------------------------------------------

/* A method that returns simple type cannot be overrided to
  return different type. */
class F {
	int f() { return 1; }
}
class G extends F {
	// double f() { return 1.0; }		// error
}

/* A method that returns reference type may be overrided to
  return a sub-class of the reference type. */
class X { }
class Y extends X { }
class M {
	X f() { return new X(); }
}
class N extends M {
	Y f() { return new Y(); }
}
