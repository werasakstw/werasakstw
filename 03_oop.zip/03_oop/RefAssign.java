/* References of ancestor classes may point to
  instances of descendant classes. */
class A {
	int x = 1;
}
class B extends A {
	int y = 2;
}
class RefAssign {
	public static void main(String args[]) {
		A a = new A();
		B b = new B();
		a = b;
	}
}
