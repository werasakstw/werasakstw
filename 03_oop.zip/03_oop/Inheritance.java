class A {
	// Private members are inherited but not accessible.
	private int x = 1;
	public int getX() { return x; }

	// Non-private static members are inherited.
	static int s = 2;
}
class B extends A {
	public void f() {
		// System.out.print(x);			//error
		System.out.println(getX());
		System.out.println(s);
	}
}

class Inheritance {
	public static void main(String[] args) {
		new B().f();
	}
}
