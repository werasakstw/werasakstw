import com.mypack.A;
/* Visibility semantics must be detremined with
  class extension and package. */

class SubClassOtherPack extends A {
	public void print() {
		System.out.println(x3 + x4);
	}
}

class OtherClassOtherPack {
	public void print() {
		A a = new A();
		System.out.println(a.x4);
	}
}

/*					Visibility Modifiers
									private		defaul	protected	 public
Same Class Same Package		   yes		 yes		  yes			  yes
Sub Class Same Package		   no		 	yes		  yes			  yes
Other Class Same Package	   no		 	yes		  yes			  yes
Sub Class Other Package	  	   no		  	no		  	  yes			  yes
Other Class Other Package	   no		  	no		     no			  yes
*/
