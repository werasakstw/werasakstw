package com.mypack;

public class A {
	private int x1 = 1;;
	int x2 = 2;
	protected int x3 = 3;
	public int x4 = 4;
	
	public void print() { 
		System.out.println(x1 + x2 + x3 + x4);
	}
}

class SubClassSamePack extends A {
	public void print() { 
		System.out.println(x2 + x3 + x4);
	}
}

class OtherClassSamePack {
	public void print() {
		A a = new A();
		System.out.println(a.x2 + a.x3 + a.x4);
	}
}