class A {
	public void f() { System.out.println("A.f"); 	}
}

// Composition
class C {	// C is a user of class 'A'.
	private A a = new A();
	public void f() { a.f(); }	// forwarding
	public void g() { System.out.println("C.g"); }
}

// Extension
class E extends A {  // E is a child of class 'A'.
	public void g() { System.out.println("E.g"); }
}

class ReUse {
	public static void main(String args[]) {
		C c = new C(); c.f(); c.g();
		E e = new E(); e.f(); e.g();
	}
}
