import java.util.Objects;

/* Java7 introduce a service class 'java.util.Objects' for null-safe operations.
All Object's contract methods should be modified to forward to these methods. */
class NullSafeObject {
	public static void main(String args[]) {
		class A {
			Integer x;
			A(Integer x) { this.x = x; }
			public boolean equals(Object o) {
				return (o instanceof A) && x.equals(((A) o).x);
			}
		}
		A a1 = new A(null);
		A a2 = new A(null);
		// System.out.println(a1.equals(a2));   // error:

		class B {
			Integer x;
			B(Integer x) { this.x = x; }
			public boolean equals(Object o) {
				return Objects.equals(x, ((B)o).x);
			}
		}
		B b1 = new B(null);
		B b2 = new B(null);
		System.out.println(b1.equals(b2));   // true
	}
}
