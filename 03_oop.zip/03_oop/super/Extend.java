/*	Overriding is to replace the method with a new one.
	Extending is to execute the old method and do something extra.
*/
class A {
	void f() { System.out.println("A"); }
}
class B extends A { 	// override
	void f() { System.out.println("B"); }
}
class C extends A { 	// extend
	void f() {
		super.f();
		System.out.println("C");
	}
}
class Extend {
	public static void main(String args[]) {
		new B().f();
		new C().f();
	}
}
