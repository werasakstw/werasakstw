/* 1. When a constructor of a base class is newed, all constructors
of its ancestors are executed from top down.

 2. If the first statement of a constructor has no this() or super(),
the compiler will give an empty super().

 3. There are two ways to make a class non-extensible.
 	- uses the 'final' keyword.
 	- make the class has only private connstructor. This also made the class non-newable.
*/
class A {
	A() { System.out.println("A"); }
	A(String c) { System.out.println("A(" + c + ")"); }
}
class B extends A {
	B()  { System.out.println("B"); }
	B(String c) { super("hello"); System.out.println("B(" + c + ")"); }
}
class ConsChain {
	public static void main(String args[]) {
		new B();
		// new B("hi");
	}
}
//-------------------------------------------
/* We should design the class hierarchy so that:
  1. Only the designated constructor needs to chain upward.
  2. Constructors should initialize only the data that defined
      in its class.
	 e.x. Bad
			 	class A {
					protected int a;
				}
				class B extends A {
					private int b;
					B(int a, int b) { super.a = a; this.b = b; }
				}
*/
class C {
	int x;
	C() { this(0); }
	C(int x) { this.x = x; }
	C(C c) { this(c.x); }
}
class D extends C {
	int y;
	D() { this(0, 0); }
	D(int x, int y) { super(x); this.y = y; }
	D(D d) { this(d.x, d.y); }
}
