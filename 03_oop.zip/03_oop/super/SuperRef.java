/*  Java provides 'super' reference for accessing members
 of the nearest ancestor that are shadowed or overrided. */
class A {
	int a = 1;
}
class B extends A {
	int a = 2;
	void print() {
		System.out.println(super.a + "," + this.a);
	}
}
class C extends B {
	int a = 3;
	void print() {
		System.out.println(super.a + "," + this.a);
	}
}
class SuperRef {
	public static void main(String args[]) {
		new B().print();
		new C().print();
	}
}
