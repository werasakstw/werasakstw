/*  super() is used in sub-class to call the constructor
 of the super-class. Calling super() must be at the first
 statement of a constructor and once only.
There will be either this() or super() not both, but none
  is allowed. */
class A {
	A(String s) {
		System.out.println(s);
	}
}
class B extends A {
	B() {
		super("Hello");
		System.out.println("Hi");
	}
}
class SuperCons {
	public static void main(String args[]) {
		new B();
	}
}
