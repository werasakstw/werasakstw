/* If the parameter of System.out.print() or System.out.println(a) is
	- a String then it will be sent to System.out.
	- an instance that is not String it will be called toString() then sent out.
	- a simple type it will be converted into String then sent out.
java.lang.Object provides the default implmentation of toString().
For our entity class we should override toString() to provide
 the string representation of the instance.
Normally toString() should return the instance state as a string. */
import java.util.Date;
class Student {
	private int id;
	private String name;
	Student(int id, String name) {
		this.id = id; this.name = name;
	}
	// public String toString() { return id + "," + name; }
}
class ToString {
	public static void main(String args[]) {
		Student a = new Student(123, "John Rambo");
		System.out.println(a);

		// Standard lib classes have toString() implemented.
		System.out.println(new String("Hello"));
		System.out.println(new Date());
	}
}
