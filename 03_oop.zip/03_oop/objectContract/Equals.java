/* The operator == compares simple types by value but compares
 reference types by reference.
The java.lang.Object provides equals() but compares by reference.
To compare reference types by value, we must override equals()
 to provide the semantics for equality.

There are some kinds of objects that do not needed to be compared.
 e.g. non-entity objects and function-thread objects.
So we do not need to override equals().
If the equals() should never be invoked at all,
   then it should throw UnsupportedOperationException. */
class Student {
	private int id;
	private String name;
	Student(int id, String name) {
		this.id = id; this.name = name;
	}
/*	public boolean equals(Object o) {
		if (o != null && o instanceof Student) {
			Student s = (Student) o;
			if (id == s.id)
				return true;
		}
		return false;
	}
*/
}
class Equals {
	public static void main(String args[]) {
		Student a = new Student(123, "John Rambo");
		Student b = new Student(123, "John Rambo");
		System.out.println(a == b);
		System.out.println(a.equals(b));

		String x = new String("Hello");
		String y = new String("Hello");
		System.out.println(x.equals(y));
	}
}
