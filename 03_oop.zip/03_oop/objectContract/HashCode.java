import java.util.*;
/* java.lang.Object provides hasCode() for hashing
 the instances of the class. The contract is:

1. Whenever hashCode() is invoked on the same object,
it must return the same integer. The result need not
to be the same from execution to execution.

2. If two objects are equal according to equals(),
then the hashCode() must return the same value.

3. hashCode() should compute a value from the members
that used by equals(). */

class Student {
	private int id;
	private String name;
	Student(int id, String name) { this.id = id; this.name = name; }
	public boolean equals(Object o) {
		if (o != null && o instanceof Student) {
			Student s = (Student) o;
			if (id == s.id)
				return true;
		}
		return false;
	}
	// public int hashCode() { return id; }
}
class HashCode {
	public static void main(String args[]) {
		Map<Student, String> h = new HashMap<Student, String>();
		h.put(new Student(123, "John Rambo"), "BadGuy");
		System.out.println(h.get(new Student(123, "John Rambo")));

		System.out.println(new String("Hello").hashCode());
		System.out.println(new String("Hello").hashCode());
	}
}
