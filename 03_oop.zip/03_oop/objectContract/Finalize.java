/* Before an object is garbage collected, its finalize() is called.
 We should override finalize() to provide the last action if needed.
We cannot determine when an object will be a garbage and it can take
 a long time for a garbage to be collected and if the JVM stops ruptly
 some garbages will not be collected. There is no guarantee that
 finalize() will be executed.
  - Nothing time-critical should ever be done by finalize().
  - Never depend on finalize() to update critical persistent state.

 There are only two valid uses of finalize():
	- To act as a "safety net" in case the users of the object
forget to call the explicit termination methods. e.g. InputStream,
OutputStream and Timer have finalize()
	- To garbage collect an instance that uses native code,
because it is not a normal object, the garbage collector
doesn't know about its memory usage.

In case a class needs to perform a post-active activity.
 Define an explicit termination method. Ex.
			 class A {
				........
				public void stop() {
					// perform post-active activity
				}
			}
 Ex.
		java.util.Timer.cancel()
		java.awt.Graphics.dispose()
		java.awt.Window.dispose()
		java.awt.Image.flush()
*/
class A { // finalize() is deprecated.
	A() { System.out.println("Hello"); }
	protected void finalize() throws Throwable {
		System.out.println("Bye");
	}
}
class Finalize {
	public static void main(String args[]) {
		new A();
		// System.gc();		// request the gc to execute promptly.
	}
}
