/* Generic means does not specified to a certain type.
C++ implements generic using template, Java uses polymorhims.
There are two kinds of generic:
1. Generic Datastructure is a datastructure(e.g. array or stack)
   that contains instances of any classes or a family of classes.
Java uses 'Object' reference to hold instances of any classes.  */
import java.awt.Color;
import java.util.*;
class GenericData {
// class Generic {
	public static void main(String args[]) {
		Object a[] = {Color.RED, "Hello", new Date()};
		for (Object x: a)
			System.out.println(x);
	}
}

/* 2. Generic Method is a method that accepts parameters of
 any classes or a family of classes. */
class GenericMethod {
// class Generic {
	static void f(Object o) {System.out.println(o); }
	public static void main(String args[]) {
		f(Color.RED);
		f("Hello");
		f(new Date());
	}
}

/* Java is a 'no-pure' object-oriented language, that means
 having both simple types and reference type.
Simple type variables are not objects and cannot be assigned to
 Object reference. Therefore we cannot have array of generic simple type.
Java 2 provides a solution by introcudcing 'type wrapper classes'.
 		Simple Types				Type Wrapper Classes
 			boolean						Boolean
		    byte							Byte
		    short						Short
		    char							Character
		    int							Integer
		    long							Long
		    float						Float
		    double						Double
   ex.
   			int x = 1;
   			Integer y = new Integer(x);
   			int z = y.intValue();
To simplify the matter, Java 5 introduced Autobox, which automatic
 wrapping simple type values as needed. */
class TypeWrapper {
// class Generic {
   @SuppressWarnings("deprecated")  // does not work.
	public static void main(String args[]) {
		// jdk 1.4: Now explicit wrapping simple types are deprecated.
		// Object a[] = { new Integer(1), new Character('A'), new Boolean(true)};

		// jdk 1.5
		Object b[] = {1, 'A', true};
	}
}

/* Autoboxing is proofed to be handy but does not make 'pure' oop.
		Integer inc(Integer x) {
			int y = x.intValue();
			++y;
			return new Integer(y);
		}     */
class Autoboxing {
// class Generic {
	static Integer inc(Integer x) {
		return ++x;
	}
	public static void main(String args[]) {
			Integer a = 1;
			System.out.println(inc(a));
	}
}

// Java 2 introduced Collection which is a set of generic data structures.
class CollectionTest {
// class Generic {
	@SuppressWarnings("unchecked")
	public static void main(String args[]) throws Exception {
		Stack s = new Stack();
		s.push(1); s.push(1.0); s.push("Hello");
		while(!s.empty())
			System.out.print(s.pop() + ",");
	}
}
/* Syntax errors are grammar errors.
	  Ex. illegal characters, invalid variable names, unbalance begin and end.
	Semantic errors are logical errors.
	  Ex. array index out of bound, divided by zero, invalid input values

All syntax errors and some of semantic errors are detectable at compile time.
Type error is a subset of semantic errors.
If a language is designed so that all typed errors are detectable at compile time
  then we call it a strongly typed language or type safe.

The generic that was introduced in java 2 makes Java a type unsafe language. */
class TypeUnSafe {
// class Generic {
	@SuppressWarnings("unchecked")
	public static void main(String args[]) {
		Stack s = new Stack();
		// s.push(1); s.push(2);
		s.push("1"); s.push("2");
		Integer a = (Integer) s.pop();
		Integer b = (Integer) s.pop();
		System.out.print(a.intValue() + b.intValue());
	}
}
