/* Java10 type inference allows declaration without explicit type.
'var' allows defining variable or reference with implicit type.
 - must be in local scope, not allowed for parameters.
 - must be initiallized with value of known type at compile time. */
import java.util.*;
class TypeInference {
   public static void main(String args[]) {
      var x = 1;
      System.out.println(x);

      var y = 1.0/2;
      System.out.println(y);

      // 'null' type cannot be inferred.
      // var z = null;     // error:

      // Generic type must be explicitly defined with type parameters.
      var list = new ArrayList<String>();
      list.add("Hello"); list.add("Hi");
   }
}
