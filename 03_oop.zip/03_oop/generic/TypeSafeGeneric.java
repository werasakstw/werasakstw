import java.util.*;

/* Java 5 introduced 'type safe' generic that allows checking
 type errors at compile time. The Java approach is allowing
 'type parameter' for classes and methods.
1. Type safe generic class.
 */
 class A<T> {	// T is a type parameter to class 'A'.
 	T t;
 	A(T t) { this.t = t; }
 	public T getT() { return t; }
 	public void setT(T t) { this.t = t; }
 }
class GenericClass {
// class TypeSafeGeneric {
	/* Type safe generic needs type initiating so that
	the compiler knows what the type parameter will be. */
	public static void main(String args[]) {
		A<Integer> a1 = new A<Integer>(1);
		A<String> a2 = new A<String>("Hello");
		System.out.println(a1.getT() + ", " + a2.getT());
		// a1.setT("1");			// compiler time error
		// a1 = a2;					// compiler time error

		// Since Java5 all collections are generic.
		Stack<Integer> s = new Stack<Integer>();
		s.push(1);
		// s.push(2.0);			// compiler time error
	}
}

/* 2. Type safe generic method.
The type parameters are defined before the return type.
So that they can be used in the method parameters. */
class GenericMethod {
// class TypeSafeGeneric {
	static <T, S extends T> boolean isMember(T t, S s[]) {
		for(int i = 0; i < s.length; i++)
			if(t.equals(s[i]))
				return true;
		return false;
	}
	public static void main(String args[]) {
		Integer a[] = {1,2,3,4,5};
		System.out.println(isMember(2, a));

		Double d[] = {1.0, 2.0, 3.0, 4.0, 5.0};
		System.out.println(isMember(7.0, d));
	}
}

// Restriction for using type safe generic:
class Restriction<T> {
	T t1;
	// T t2 = new T(); 	// type parameter cannot be instantiated
	// static T t3;		// type parameter cannot be static
	// static T getT() { return t1; }
	 						  // static method cannot access type parameter

	T a[];	// It's ok to define a reference to array of type parameter
	// a = new T[10];	// But cannot create an array of type parameter
}

// To simplify type safe generic collection defintions.
class DiamondOp {
	public static void main(String args[]) {
	/* Pre-Java7: both left and right hand sides must be
	explicit type parameterized.  */
		List<String> a = new ArrayList<String>();
		a.add("Helo");

	// Java 7 introduces <>, diamond operator.
	// <> allows type inference, no need to repeat the type parameter.
		List<String> b = new ArrayList<>(); // Try: remove <>.
		b.add("Hi");

	// Java 9 introduces anonymous class with diamond operator.
		List<String> l = new ArrayList<>(){ };

	// Implicit type is allowed with warning, default is <Object>.
		// List c = new ArrayList<String>();
		// List<String> x = new ArrayList();
	}
}

/* When a type parameter can be inferred from assigned or passed
 value, it is allowed to use a wildcard ? for specify any types. */
class NumberArray<T extends Number> {
	private T t[];
	NumberArray(T t[]) { this.t = t; }
	public double average() {
		double s = 0.0;
		for (T x : t)
			s += x.doubleValue();
		return s / t.length;
	}

	boolean sameAvg(NumberArray<?> na) {
		return (average() == na.average())? true : false;
	}
}
class WildcardArg {
// class TypeSafeGeneric {
	public static void main(String args[]) {
		Integer i[] = {1,2,3,4,5};
		// The type parameter may be inferred by the compiler.
		NumberArray<?> ia = new NumberArray<>(i);
		System.out.println(ia.average());

		Double d[] = {1.0, 2.0, 3.0, 4.0, 5.0};
		NumberArray<?> da = new NumberArray<>(d);
		System.out.println(da.average());

		System.out.println(ia.sameAvg(da));
	}
}

/* A type parameter can be bound to a super class
  which allows certain family of classes.  */
class X { }
class B extends X { }
class C extends X { }
class D { }
class G<T extends X> {
	private T t;
	G(T t) { this.t = t; }
	public T getT() { return t; }
	public void setT(T t) { this.t = t; }
}
class BoundGeneric {
// class TypeSafeGeneric {
	public static void main(String args[]) {
		G<X> g = new G<X>(new X());
		g.setT(new B());
		g.setT(new C());
		// g.setT(new D());
	}
}
