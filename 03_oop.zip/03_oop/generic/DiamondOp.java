import java.util.ArrayList;
import java.util.List;

class DiamondOp {
	public static void main(String args[]) {
	/* Pre-Java7: both left and right hand sides must be
	explicit type parameterized.  */
		List<String> a = new ArrayList<String>();
		a.add("Helo");
		System.out.println(a);

	// Java7 introduces <>, diamond operator.
	// <> allows type inference, no need to repeat the type parameter.
		List<String> b = new ArrayList<>(); // Try: remove <>.
		b.add("Hi");
		// b.add(1);	// error:
		System.out.println(b);

	// Java9 introduces anonymous class with diamond operator.
		List<String> l = new ArrayList<>(){ };

	// Implicit type is allowed with warning, default is <Object>.
		// List c = new ArrayList<String>();
		// List<String> x = new ArrayList();

	// Java9 introduces anonymous class with diamond operator.
		List<String> m = new ArrayList<>(){ };
	}
}
