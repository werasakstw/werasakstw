/* Pre-Java8 Interface
Interfaces are 'pure' specification. */
interface I1 {
	// All data members must be static, final, and initialized
	// int x;
	static final int y = 1;

	// All method members must be abstract and cannot be static.
	// void f() { }
	abstract void g();

	// All members are public by defulat.
}

// Testing the default.
interface I2 {
	int x = 1;		// public static final by default
	void f();		// public abstract by default
}
//--------------------------------------------------

/* Java 8 allows interfaces to have:
	1. Default method.
	2. Static methods.
That allows using interfaces as 'non-pure' specifications. */
interface I8 {
	default void f() { System.out.println("default"); }
	static public void g() { System.out.println("static"); }
}
/* Interfaces are specification and can be used as types.
Implementation means making the specification usable.
A class that implements an interface inherited the
  specification into its class and behaves a sub-type
  of the type(interface). */
class I8Impl implements I8 { }
class I8Test {
// class Interface {
	public static void main(String args[]) {
		I8Impl i = new I8Impl();
		i.f();

		// g() is belong to interface I8, not class I8Impl.
		I8.g();
		// I8Impl.g();		// error
	}
}
/* Extension and Implementation rules.
1. A class may extend exactly one parent class (default is Object).
2. A class may implement any number of interface (including none).

class A { }
interface I { }
interface J { }
class B extends A implements I, J { }
*/

/* 3. Interfaces can be extened, the result is an interface
  with possibly more specification. e.g.

interface I { void f(); }
interface J extends I { void g(); }
 */

/* 4. An interfaces can be partialliy implemented(not all methods
 implemented), the result is an abtract class. e.g.

interface I { void f(); void g(); }
abstract class A implements I { public void f(){} }
class B extends A { public void g(){} }
*/
//-------------------------------------------------------

/* Java 8 Rules of Interface Implementation:
 1. If the parent class and the interface have the same method,
 the 'class win'.  e.g.

class A { public void f() { System.out.println("A.f"); } }
interface I { default void f() { System.out.println("I.f()"); } }
class B extends A implements I { }
class Rule1Test {
// class Interface {
	public static void main(String args[]) {
		new B().f();
	}
}
*/

/* 2. If both interfaces have the same default methods,
  the class must implements its own. e.g.

interface I { default void f() { System.out.println("I.f()"); } }
interface J { default void f() { System.out.println("J.f()"); } }
class A implements I, J {
  public void f() { System.out.println("J.f()"); }
}
*/

/* 3. A method cannot be both abstract and default method in
the same interface. e.g.

interface I {
	public abstract void f();
	// default public void f() { System.out.println("K8.f"); }
}
*/

/* 4. An extended interface can implement abstract methods of the
 parent interface as default methods. e.g.

interface I { void f(); }
interface J extends I {
	default public void f() { System.out.println("J.f"); }
}
*/
///////////////////////////////////////////////////////

// Java11 introduces private method in interfaces.
interface I11 {
   private void f() {
      System.out.println("private");
   }
   private static void g() {
      System.out.println("private static");
   }
	// Private methods are visible only within the interface.
   default void h() {
      f();
      I11.g();
   }
}
