/* 'instanceof' is an operator for testing if
 an instance is of a type which may be class
 or interface. */
class A { }
class B extends A { }
interface I { }
class IImpl implements I { }
class Instanceof {
// class Tag {
	public static void main(String args[]) {
		A a = new A();
		B b = new B();
		IImpl i = new IImpl();
		System.out.println( a instanceof A );
		System.out.println( b instanceof A );
		System.out.println( i instanceof I );
	}
}
// ------------------------------------------
/* Tag(Marker) is a practice of creating a class that
 implements an interface for specify privileges or permission
 to all instance of the class.
Mostly tags are used for granting permission, so by convention
 the tag names are end with 'able'. */
interface Greetable { }
abstract class Human {
	abstract public String getName();
}
class John extends Human {
	public String getName() { return "John"; }
}
class Jack extends Human implements Greetable {
	public String getName() { return "Jack"; }
}
class GreetableTest {
// class Tag {
	static void greet(Human h) {
		if (h instanceof Greetable)
			System.out.println("Hello! " + h.getName());
	}
	public static void main(String args[]) {
		greet(new Jack());
		greet(new John());
	}
}
//---------------------------------------------------
/* java.lang.Object defines clone() for copy by value the instance.
The clone() is implemented as:
 - bitwise copy the instance (without using constructor) and
   therefore it is efficient but shallow copy.
 - 'protected', if need to call as 'public' it must be overided.
 - Cloning instance is not safe, therefore this clone() checks
   if the class has permission(to be cloned) by implementing Cloneable.
   If the class does not implement Cloneable throws CloneNotSupportException.

We must override clone() if different copy by value is needed.
clone() contracts:
	1. x is a cloneable object.
	2. x.clone() != x must be true.
	3. x.clone().getClass() == x.getClass() should be true but not required.
	4. x.clone().equals(x) should be true but not required.
*/
class Student implements Cloneable {
	private int id;
	private String name;
	Student(int id, String name) {
		this.id = id; this.name = name;
	}
	public void setName(String n) { name = n; }
	public String toString() { return id + "," + name; }

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}
class CloneTest {
// class Tag {
	public static void main(String args[]) {
		Student x = new Student(123,"John Rambo");
		Student y = null;
		try {
			y = (Student) x.clone();
		}
		catch(CloneNotSupportedException e) {
			System.err.println("Clone() not supported");
		}
		System.out.println(x + "\t" + y);
		System.out.println(x == y);
	}
}
