/* Companion(or utility) classes are classes for working
 with a class that implements an interface.
PreJava 8:  */
interface A {
	public int get();
}
class AImpl implements A {
	private int x;
	AImpl(int x) { this.x = x; }
	public int get() { return x; }
}
/* Normally a companion is not related to the working class,
 but needs to access private memebers of the class. */
class AComp {
	public static A add(A a1, A a2) {
		return new AImpl(a1.get() + a2.get());
	}
}

/* Java 8: Using interface static methods, companion needs
 not to be a separated class but included in the interface. */
interface B {
	public int get();
	static public B add(B b1, B b2) {
		return new BImpl(b1.get() + b2.get());
	}
}
class BImpl implements B {
	private int x;
	BImpl(int x) { this.x = x; }
	public int get() { return x; }
}
class Companion {
	public static void main(String args[]) {
		A a1 = new AImpl(1);
		A a2 = new AImpl(2);
		System.out.println(AComp.add(a1, a2).get());

		B b1 = new BImpl(1);
		B b2 = new BImpl(2);
		System.out.println(B.add(b1, b2).get());
	}
}
