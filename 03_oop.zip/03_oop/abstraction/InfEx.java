/* Tightly Coupling means a caller and its callee
 is permanently fixed, changing needs recompilation.

class A {
	public void f() { System.out.println("A.f()"); }
}
class TightlyCoupling {
	public static void main(String args[]) {
		A a = new A();
		a.f();
	}
}
*/

/* Decoupling with Interface:
1. Create an interface with all the methods called by the user.
2. Make the usee class implements the interface.
3. In the user class, replace all the references to the usee
  with the references to the interface.
*/
import java.util.*;
interface I { void f(); }
class A implements I {
	public void f() { System.out.println("A.f()"); }
}
class B implements I {
	public void f() { System.out.println("B.f()"); }
}
class Decoupling {
// class InfEx {
	public static void main(String args[]) {
		I i = new A();   // new B();
		i.f();
	}
}

// Using Factory
abstract class IFactory {
	public static I getInstance(String name){
		return name.equals("A")? new A() :
				name.equals("B")? new B() : null;
	}
}
class Factory {
// class InfEx {
	public static void main(String args[]) {
		I i = IFactory.getInstance("A");
		i.f();
		i = IFactory.getInstance("B");
		i.f();
	}
}

// Using Class Object NewInstance
abstract class NewIFactory {
	public static I getInstance(String name) throws ClassNotFoundException,
			IllegalAccessException, InstantiationException {
		return (I) Class.forName(name).newInstance();
	}
}
class NewInstance {
// class InfEx {
	public static void main(String args[]) throws Exception {
		I i = NewIFactory.getInstance("A");
		i.f();
		i = NewIFactory.getInstance("B");
		i.f();
	}
}

//----------------------------------------------------
/* At the beginning of design processes, we should consider:
 - What(codes) we already have:
 		-- if the code fit requirement so includes it.
		-- if the code is slightly different so adapts it.
      -- if no code for the requirement or too hard to adapt so implements it.

Adaptation is to create a class from existing classes to satisfy
  a spacification defined by a interface.There are two ways:
	- extension (derive a new class from a usable one and
       add new methods to match the desired interfaces).
	- composition (include the existing class into the new class
      and create methods match the desired interfaces).

Using Interface as a spacification:
*/
class Adaptation {
// class InfEx {
	static interface Spec {
		public abstract void greet();
		public abstract void farewell();
	}
	// Suppose there exists a 'Hello' class.
	static class Hello {
		public void greet() { System.out.println("Hello!"); }
	}

	// Extension
	static class A extends Hello implements Spec {
		public void farewell() { System.out.println("Goodbye."); }
	}

	// Composition
	static class B implements Spec {
		private Hello h = new Hello();
		public void greet() { h.greet(); }
		public void farewell() { System.out.println("Goodbye."); }
	}

	public static void main(String args[]) {
		A a = new A(); a.greet(); a.farewell();
		B b = new B(); b.greet(); b.farewell();
	}
}
//-------------------------------------------------------

/* Some interfaces have a lot of methods and hard to implement.
We can simplify implementing this kind of interfaces with
 partially implementation. */
 interface X {
 	void f1();
 	void f2();
 	void f3();
 }
 /* It is hard to implement all methods, and some methods
   may never used at all. Suppose we need only f1(). */
 class XImpl implements X {
 	public void f1() { System.out.println("f1"); }
 	public void f2() {}
 	public void f3() {}
 }
 //-----------------------------------------------------
 /* An adapter is an abstract class that provide empty
 implementations for all the methods of an interface.
 e.g.
 	java.awt.event.WindowAdapter
 	java.awt.event.KeyAdapter
 	java.awt.event.ComponentAdapter
 	org.xml.sax.helpers.ParserAdapter
 */
  abstract class XAdaptor implements X {
 	public void f1() {}
 	public void f2() {}
 	public void f3() {}
 }
 // So implementing X for only f1() would be simple.
 class XImpl2 extends XAdaptor {
 	public void f1() { System.out.println("f1"); }
 }
 //-----------------------------------------------------
 /* Abstract Adapter classes (or Template) provide default implementations
 which are not empty for some the methods of the interface.
 e.g.
 	java.util.AbstractList
 	java.util.AbstractSet
 	javax.swing.AbstractAction

 Suppose the default implementations of f1() and f2() are provided. */
abstract class AbstractX implements X {
	public void f1() { System.out.println("f1"); }
	public void f2() { System.out.println("f2"); }
	abstract public void f3();
}
class XImpl3 extends AbstractX {
	public void f3() { System.out.println("f3"); }
}
//--------------------------------------------------------
/* Default (or Simple) Adapter classes provide default por simple
 implementations for all the methods of the interface
e.g.
	javax.swing.DefaultListModel
	javax.swing.table.DefaultTableModel
	org.xml.sax.helpers.DefaultHandler

	java.beans.SimpleBeanInfo
	com.sun.media.sound.SimpleInputDevice
	java.text.SimpleTextBoundary
	sun.security.validator.SimpleValidator
	java.util.SimpleTimeZone  */
class SimpleX implements X {		// or DefaultX
	public void f1() { System.out.println("f1"); }
	public void f2() { System.out.println("f2"); }
	public void f3() { System.out.println("f3"); }
}
class XImpl4 extends SimpleX {  // override only the unfitted
	public void f1() { System.out.println("F1"); }
}
//////////////////////////////////////////////////////////

// Java 8 do not need those adaptors.
interface I8 {
	default public void f1() { }
	default public void f2() { }
	default public void f3() { }
}
class I8Impl implements I8 {
	public void f1() { System.out.println("Hello"); }
}
///////////////////////////////////////////////////////

/* A sequence is a collection of order-oriented elements.
'Iterator' allows iterating a sequence without knowing
  its internal representation. Ex. C++ List Iterator:

	  	list<int> l;
	  	for (int c = 1; c < 10; c++)
	  		l.push_back(c);

	  	list<int>::iterator i;
	  	for (i = l.begin(); i != l.end(); i++)
	  		cout << *i << ",";

Enumerate means handing out one element at time.
Java provides 'Enumeration' interface to specify that
  objects of the class can be enumerated. */
class MyEnumeration implements Enumeration<String> {
	private int i = 0;
	private static String a[] = { "John", "Jack", "Joe" };
	public boolean hasMoreElements() { return i < a.length; }
	public String nextElement() { return  a[i++]; }
}
class MyEnumerationTest {
// class InfEx {
 	public static void main(String args[]) {
		MyEnumeration me = new MyEnumeration();
		while (me.hasMoreElements())
			System.out.print(me.nextElement() + ", ");
	}
}
// Java 1.2 introduced 'Iterator' interface for more meaningful.
class MyIterator implements Iterator<String> {
	private int i = 0;
	private static  String a[] = { "John", "Jack", "Joe" };
	public boolean hasNext() { return i < a.length; }
	public String next() { return  a[i++]; }
	public void remove() { }
	// Removing element from the underlying collection is rare.
}
class IteratorTest {
// class InfEx {
 	public static void main(String args[]) {
		MyIterator mi = new MyIterator();
		while (mi.hasNext())
			System.out.print(mi.next() + ", ");
	}
}

/* java.lang.Iterable is an interface to specify that the
 class has an iterator which can iterate a sequence, which
 may be itself.

To made an iterator object supports fast for loop, it must
 implement Iterator and Iterable, which iterator() just
 return 'this'.  */
class C implements Iterator<String>, Iterable<String> {
	private int i = 0;
	private static  String a[] = { "John", "Jack", "Joe" };
	public boolean hasNext() { return i < a.length; }
	public String next() { return  a[i++]; }
	public void remove() { }
	public Iterator<String> iterator() { return this; }
}
// class CTest {
class InfEx {
	public static void main(String args[]) {
		for(String s : new C())
			System.out.print(s + ", ");
	}
}
