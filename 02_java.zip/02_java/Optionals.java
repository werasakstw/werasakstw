import java.util.NoSuchElementException;
import java.util.Optional;
/* Calling a method on null references causes a NullPointerException.
Null pointer exceptions are semantic error that cannot be detected
 at compile time.  */
class NullExcept {
// class Optionals {
	public static void main(String[] args) {
		// String s = null;
		String s = "Hello";
		// s = null;
		System.out.println(s.length());
	}
}

/*	Java 8 offers Optional to deal with NullPointerException.
Optional<T> is a wrapping class for a class T that may or
 may not contain a value. */
class OptionalTest {
// class Optionals {
	public static void main(String[] args) {
		// <T> Optional<T> empty(): Returns an empty Optional T.
		Optional<String> o1 = Optional.empty(); // no value optional string
		System.out.println(o1);

		// <T> Optional<T> of(T value): Returns an Optional T containing a value.
		// Optional<String> on = Optional.of(null); // runtime error
		Optional<String> o2 = Optional.of("Hello"); // parameter must be non-null
		System.out.println(o2);

		/* <T> Optional<T> ofNullable(T value):
 		If the value is non-null, it returns an Optional containing the value.
 		If the value is null, it returns an empty Optional.
 		   So It does not matter if the parameters are null or not. */
		Optional<String> o3 = Optional.ofNullable(null);
		System.out.println(o3);

		Optional<String> o4 = Optional.ofNullable("Hello");
		System.out.println(o4);
	}
}

/*	It is possible that the wrapped values are null.
We use Optional to wrap a possibly null value just to prevent
 calling methods of the class that may cause NullPointerException.
  ex. We cannot perform normal string operations on an instance
   of Optional<String>.  */
class OptionalGet {
// class Optionals {
	public static void main(String[] args) {
		Optional<String> n = Optional.ofNullable(null);
		Optional<String> h = Optional.ofNullable("Hello");

		/* An optional string is not a String, but toString() is possible.
		And it can be appended (+), the result is an optional string.
		Calling these methods on empty optional string does not causes
		 NullPointerException. */
		System.out.println(n + " John");
		System.out.println(h + " Jack");

		/* To access the wrapped value we need an unwrapping method:
		 	 get()   returns the wrapped value of the optional.  */
		System.out.println(h.get());

		// Unwrapping an empty optional causes a NoSuchElementException.
		try {
			System.out.println(n.get());
		} catch (NoSuchElementException ex ) {
			System.out.println("No value");
		}

		/*  Using try-catch is clumsy and less efficient, if-then-else is better.
			isPresent() can determine if the optional has a value. */
		if (n.isPresent())
			System.out.println(n.get());
		else
			System.out.println("No value");

		if (h.isPresent())
			System.out.println(h.get());
		else
			System.out.println("No value");

	/* It will be a normal practice that we must check before getting the values.
	But using if-statement when accessing optional values is so awkward.
	Java 8 provides 4 alternatives to handle the situation. */

	/* 1. orElse(<default>) return the default value if the optional has no value.
	   So we do not need the if statement and isPresent(). */
		System.out.println(n.orElse("Hi"));
		System.out.println(h.orElse("What's up?"));

	// 2. ifPresent(<Function>) performs the <Function> if the the optional has a value.
		n.ifPresent(x -> System.out.println(x + " John"));
		h.ifPresent(x -> System.out.println(x + " Jack"));

	// 3. orElseGet(<Supplier>) returns the value of <Supplier> if the the optional has no value.
		System.out.println(n.orElseGet(() -> "Joe"));
		System.out.println(h.orElseGet(() -> "Jame"));

	// 4. orElseThrow(<Exception>) returns the value if the the optional has a value, else throws the <Exception>.
		try {
			System.out.println(n.orElseThrow(Exception::new));
		} catch (Exception ex ) {
			System.out.println("Empty");
		}
		try {
			System.out.println(h.orElseThrow(Exception::new));
		} catch (Exception ex ) {
			System.out.println("Empty");
		}
	}
}

/* When we create and use an instance we should certainly know
 if it is null or not? But when the instance is created or returned
 from a method, we should never assume that it will be non-null.
So from now on, Java 8 forces you to think in this way: */

// class OptionalReturned {
class Optionals {
	static Optional<String> hello(String name) {
		if (name.equals("John"))
			return Optional.empty();
		return Optional.of("Hello " + name);
	}

	public static void main(String[] args) {
		Optional<String> os = hello("John");
		if (os.isPresent())
			System.out.println(os.get());

		os = hello("Jack");
		if (os.isPresent())
			System.out.println(os.get());

		System.out.println(hello("John").orElse("Hi Joe"));
		System.out.println(hello("Jame").orElse("Hi Jim"));

		hello("Jeff").ifPresent(System.out::println);
	}
}
