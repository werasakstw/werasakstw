/* A class is a type.
An object is a variable(or instance) of a class.
Entity objects have their own state.
A state is the value in data members of the object.
Objects of the same class have the same behaviour.
Behaviours are actions that performed by methods. */
class Student {
	int id;
	String name;
	Student(int _id, String _name) {
		id = _id;
		name = _name;
	}
	void print() {
		System.out.println(id + ": " + name);
	}
}
class StudentTest {
// class Instances {
	public static void main(String args[]) {
		Student john = new Student(1, "John");
		Student jack = new Student(2, "Jack");
		john.print();
		jack.print();
	}
}
//----------------------------------------------------

/* All loaded class are represented as 'class object' of
  the class. They are used for holding information and
  creating instances of the class.
All used classes are loaded once by class loader, and have
  only one class object per class.
Java provide 'Class' class for creating class objects.
Class object can be accessed at runtime as the following:  */
class A { }
class ClassObj {
// class Instances {
	// References to class objects are normal reference(4 bytes).
	public static void main(String args[]) {
	// getClass()  // which is get from an instance of the class.
		A a = new A();
		Class<? extends A> c1 = a.getClass();
		System.out.println(c1.getName());

	// forName(<class name>) where <class name> is a string.
		try {
			Class<?> c2 = Class.forName("A");
			System.out.println(c2.getName());
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

	/* <class>.class operator where <class> is embedded class name.
	.class is allowed to applied to simple types. ex. int.class .
	It is used mostly as the class id of the class.*/
		Class<A> c3 = A.class;
		System.out.println(c3.getName());
	}
}
//-----------------------------------------------------

/* Constructor is a mechanism for initializing object state.
A constructor has the same name as the class.
A constructor has parameters and body like methods but no 'return type'.
A constructor must be activated with 'new', the result is the
  reference of the newly created and initialized object. */
class B {
  	int x;
  	B(int _x) { x = _x; }
} // A name with _ prefixed just denotes it is local, no special meaning.
class ConstructorTest {
// class Instances {
	public static void main(String args[]) {
		B b = new B(1);
		System.out.println(b.x);
		// Constructors cannot be invoked via object reference.
		// b.A(2);			// error
	}
}

/* A class without a constructor would have a default constructor
  which has empty parameters and body. e.g. A() {}
A 'public' class would have a 'public' default constructor and
  a 'default' class would have a 'default' default constructor.*/
class C { } 				// Try: javap C

// A class with at least one constructor would not have the default one.
class D { D(int x) {} }

/* A constructor but be activated with 'new' and result an object reference.
Constructors should not return anything. But some compilers and versions
  just ignore the consequence. */
class E { int E() { return 1; } }

// A Java compiler may or may not allow a constructor to return 'void'.
class F { void F() { } }

// Constructors cannot be static, final, synchronized nor native.
//----------------------------------------------------------

/* 'this' is a keyword which can be used to two contexts.
1. 'this' reference which is a built-in 'self reference',
  mostly used for passing as parameter to others objects
  and for distinguish between object member and local name. */
class G {
	int x;
	G(int x) { this.x = x; }
}

/* CallBack: An object send its reference to other object
 so that the reference can be used for call back to its methods. */
class H {
	void f(I i) { i.h(this); }
	void g() { System.out.println("H.g"); }
}
class I {
	void h(H h) { System.out.println("I.h"); h.g(); }
}
class CallBack {
// class Instances {
	public static void main(String args[]) {
		H h = new H();
		I i = new I();
		h.f(i);
	}
}

/* 2. 'this' constructor that allows a constructor to call
  other constructor in the same class.
Allowed in constructor only, not in methods.
It must be the first statement in a constructor and once only. */
 class J {
 	J() { this(0); }
 	J(int x) {  }  // Circular calls can be detected by compiler.
 }

//----------------------------------------------------------

/* Constructors should be overloaded to provide more than one
  ways to 'new' an instance, but all must be consistent
  that means the result should be the same.
To made thing simple, we choose one as a 'designated constructor'
  to performs all the initialization and all other constructors
  must call to the designated constructor. */
class K {
	int x;
	K() { this(0); }
	K(int x) { this.x = x; }
	K(K k) { this(k.x); }
}
