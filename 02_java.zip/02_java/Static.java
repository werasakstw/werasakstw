/* 'static' is the ownership modifier.
Static members are belong to class.
Non-static members are belong to instance.

All static data are created on the class object at the class-loading time.
There is only one copy of the values and can be accessed by all instances of the class.
Unlike C++, Java allows static data to have any access modifier and
  may be initialized locally.
Static data members hold state of the class.

A non-static data is created on the instance when the instance is created.
Every instances has its own copy of the non-static data.
Non-static data must be accessed using the object reference.
Non static data hold state of the instance. */
class A {
	int x;
	static int s = 0;   // Static data
	A(int a) { x = a; s++; }
}
class ATest {
// class Static {
	public static void main(String args[]) {
		A a1 = new A(1);
		A a2 = new A(2);
		System.out.println(a1.x + "," + a1.s);
		System.out.println(a2.x + "," + a2.s);
		System.out.println(A.s);
	}
}
/* All methods are created on the class object.
Static methods are active when the class is loaded, they can be accessed
  with class name, but Java allows using object reference.
Non-static methods are active when the object is created and must
  accessed with the object reference. */
class B {
	void f() {
		System.out.println("f");
	}
	static void g() { 	 // static methods
		System.out.println("g");
	}
}
class BTest {
// class Static {
	public static void main(String args[]) {
		B b = new B();
		b.f();
		// Java allows calling static method via object reference.
		b.g();
		B.g();
	}
}

/* A simple rule:
    When X needs to access Y, Y must be available. */
class C {
	int x = 1;
	// static int getX() { return x; }  // error

	// static y = f();						// error
	int f() { return 1; }
}

/* When JVM loaded the first class, the class must have a static
   main() since the JVM does not create object of the class. */
class D {
	int x = 1;
	public static void main(String args[]) {
		// System.out.println(x);		// error
	}
}

/* Static blocks are executed ownce after the class is loaded.
Static blocks have access to only static members.
Static blocks are used mostly for doing something after the class loading.

Instance blocks are executed before constructor for every
  instance creating.

There is no parameters to static blocks nor instance blocks. */
class E {
	static { System.out.println("static block");	}
	{ System.out.println("instance block"); }
	E() { System.out.println("constructor"); }
}
class ETest {
// class Static {
	public static void main(String args[]) {
		new E();
		new E();
	}
}
//-------------------------------------------------

/* Entities (or Model) objects have responsibilities,
  they have methods that operate on their state.

Encapsulation means the object hides its implementation.
An approach is making all data members private and expose
  only methods that handle the object state.

For a data member x of type T,
  	- accessor(getter) is
  			public T getX() { return x; }
   - multator(setter) is
  			public void setX(T x) { this.x = x; }  */
class GoodObject {
	private int x;
	public int getX() { return x; }
	public void setX(int x) { this.x = x; }
}

/* If the object has state, it should not expose methods
  that do not handle its state. */
class BadObject {
	private int x;
	public double sq(double n) { return n * n; }
}

/* All public methods should be exposed permanently and
  never be changed, that called the class API (Application
  Programming Interface).
All private data and methods may change as the API stay the same. */
class Entities {
	static class Ball1 {
		private double mass, velocity;
		public Ball1(double m, double v) {  mass = m; velocity = v; }
		public double getVelocity() { return velocity; }
		public void setVelocity(double v) { velocity = v; }
		public double getMomentum() { return mass * velocity; }
		public void setMomentum(double mm) { velocity = mm / mass; }
	}
	static class Ball2 {
		private double mass, momentum;
		public Ball2(double ma, double mo) {  mass = ma; momentum = mo; }
		public double getVelocity() { return momentum / mass; }
		public void setVelocity(double v) { momentum = mass * v; }
		public double getMomentum() { return momentum; }
		public void setMomentum(double mm) { momentum = mm; }
	}
	public static void main(String args[]) {
		Ball1 b = new Ball1(1.0, 10.0);
		// Ball2 b = new Ball2(1.0, 10.0);
		System.out.println(b.getMomentum());	// 10.0
		b.setMomentum(5.0);
		System.out.println(b.getVelocity());	// 5.0
		b.setVelocity(20.0);
		System.out.println(b.getMomentum());	// 20.0
	}
}

/* Boundary, Services or Utility classes that do not
 represent entitiy. They have no variables
 for storing state. The class mechanisms is used
 for binding constants and service methods together.
Since they have no state, they should never be instantiated
 then their methods should be static. */
class MyMath{
	static public final double PI = 3.1415;
	static public double sq(double n) { return n * n; }
	static public double half(double n) { return n / 2; }
}
// Try: javap java.lang.Math
