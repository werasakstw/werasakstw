/* 'import' statements tell the class loader where to look for
  and load classes.
'import' statements must be defined at top level in file scopes
  and before class definitions.
Package paths should begins from the directories in the CLASSPATH.
Since the class loader starts looking for classes from the CLASSPATH.
Only public classes can be imported (not the default ones).
Java compiler automatically import 'java.lang' package.
Imported class may be specified as fully qualified class name
  or as wildcard using * for the whole package.

  In case more than one packages contain classes of the same name,
    wildcard importing is not allowed, fully qualified name must be used.
import com.mypack.*;
import com.mypack.*;
*/
import com.mypack.A;
public class Import {
	public static void main(String args[]) {
		A a1 = new A();
		a1.f();

		// In cases of ambiguous class names.
		com.yourpack.A a2 = new com.yourpack.A();
		a2.f();
	}
}

/* To prevent ambiguous package, your package name should be unique.
Java suggested that using reversed domain name as package name.
	e.g.    myproject.mydepartment.mycompany.com
		=>   com.mycompany.mydepartment.myproject
*/
