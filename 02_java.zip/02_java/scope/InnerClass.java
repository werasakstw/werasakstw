/* Java allows defining classes inside a class.
So there are outter class and inner class.
That called 'nested class' which allow extending namespace
  scopes into class scopes and block scopes.
There are three kinds of nested classes:
1. Static inner classes which are static members of a class. */
class A {
	static class B {
		void f() {
			System.out.println("Hello");
		}
	}
}
class ATest {
// class InnerClass {
	// The class path is specified statically.
	public static void main(String args[]) {
		A.B b = new A.B();            // Try: new A$B();
		b.f();
	}
}
/* Visibility Rules
Static inner class can access all static members of the outter class and
 all static members of other static inner classes in the same class.

class A {
	int x = 1;
	static private int y = 2;
	static class B {
		void print() {
			// System.out.println(x);		// x is not static
			System.out.println(y + C.z);
		}
	}
	static class C {
		static private int z = 3;
	}
}    */

//--------------------------------------------------

// 2. Member classes are non-static class members of a class.
class X {
	class Y {
		void f() { System.out.println("Hello");	}
	}
}
class XTest {
// class InnerClass {
	/* The outter class object must be created and its reference
	 is used for newing the member class object. */
	public static void main(String args[]) {
		X x = new X();
		X.Y y = x.new Y();
		y.f();
	}
}
/* Visibility Rules
class A {
	private int x = 1;
	B b = new B();
	void print() { System.out.println(b.y); }
	// the outer class can access private members of the member class

	class B {
		private int y = 2;
		void print() { System.out.println(x); }
		// the member class can access private members of the outer class
	}
	class C {
		B b = new B();
		void print () { System.out.println(b.y); }
		// a member class can access private members of another member class
	}
}
*/

//------------------------------------------------------

/* 3. Local classes are classes that defined locally inside
  a method or control block and visible in the block only. */
// class LocalTest {
class InnerClass {
	public static void main(String args[]) {
		// A is not visible here.
		class A { }
		new A();

		for (int i = 0; i < 10; i++) {
			class B { }
			new B();
		}
		// B is not visible here.
	}
}

/* Visibility Rules
Local classes can access members of the outer class and
  final local variables of the block.

class A {
	private int a = 0;
	void f(final int w, int x) {
		int y = 3;
		final int z = 4;
		class B {
			B() { System.out.println(a + w + z); }  // cannot access x and y
		}
	}
}
*/
