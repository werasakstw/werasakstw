/* Package is a directory scope.
Classes in the same directory is considered in the same package.
Packages allow organizing hierarchy classes of related topic.
The directory name is the package name.
All classes in a package must specify its package path at the
  beginning of the source code file using 'package'.
A class may be either public or default
 - Default classes are visible in the same package.
 - Public classes are visible from outside packages.
A class can access default or public members of the other class in
  the same package.
*/
// class A {
class Package {
	public static void main(String args[]) {
		// Qualified name mean specifying package path to the class name.
		com.mypack.A a1 = new com.mypack.A();
		a1.f();					// f() is public method.
		// a1.g();				// g() is default method.

		// B is default class.
		// com.mypack.B b = new com.mypack.B();

		/* Packages define its own namespace. There can be classes
		   with the same name in different packages. */
		com.yourpack.A a2 = new com.yourpack.A();
		a2.f();
	}
}
