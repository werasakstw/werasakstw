/* A lifetime of variable/object value is:
  - 'active' when its value is usable that means it is allocated.
  - 'dead' when its value is unusable that means it is de-allocated.
      or its reference is no longer available.
When an object is unusable it is called a 'garbage'.

lifetime of variable/pointer in C:
		void f() {
			int a;			// a value is created on stack.
			int *b = (int *)malloc(sizeof(int));	// b value is allocated on the heap.
			// a and b are active.
			free(b);					// b is de-allocated.
		} 	/* a is out of scope (the stack is poped).
	Therefore variable value (on stack) will not be garbage.
If no free(b), b value is still on the heap and be a garbage.
It is the programmers responsibility to prevent garbages.

Java does not support pointers for (simple type) variables.
There is no need to de-allocate variables. */
class A {
	// Simple type variables are created and destroyed with the instance
	int x;
	// y is created when f() is activated and destroy when f() is done.
	void f() { int y; }
}
/* All reference type value are allocated on the heap.
Java has no mechanism to de-allocate value but provides a garbage collector(gc)
 for automatically collect garbages.
Some memory concerned classes may have release() which is
 written in native code to de-allocate memory. */
class B {
	A x = new A();		// x is created on the heap.
	void g() {
		A y;				// y is not active yet.
		y = new A();	// y is created on the heap.
		// now y is active.
		// y = null;	// its reference is nulled, value is a garbage.
	}  // y is out of scope.
}

/* By default the gc is activated when the heap is run out.
java.lang.Runtime provides gc() to activate the gc. */
class C {
// class Lifetime {
	public static void main(String args[]) {
		Runtime rt = Runtime.getRuntime();
		System.out.println("Intially:\t\t" + rt.freeMemory());

		A a[] = new A[10000];
		for(int i = 0; i < a.length; i++)
			a[i] = new A();
		System.out.println("After a[]:\t\t" + rt.freeMemory());
		for(int i = 0; i < a.length; i++)
			a[i] = null;
		System.out.println("After nulls:\t" + rt.freeMemory());
		rt.gc();
		System.out.println("After gc():\t" + rt.freeMemory());
	}
}
//-----------------------------------------------------

/* Dangling Reference is accessing a value with invalid reference(or pointer).
   -- before the value is active or after the value is dead.
 	-- the reference type is invalid.
	-- the reference does not have the right to access the value.

Dangling References in C:
  1. C pointers can be assigned with any value.
  		int *p = 1000;
  2. C does not check array index out of bound.
   		int x, a[10];
 			a[10] = 1;
  3. C allows de-allocation value on the heap.
	 		int *p, *q;
	 		p = (int *) malloc(sizeof(int));
	 		*p = 123;
	 		q = p;
	 		free(p);
  4. C allows returning a local pointer out of its creation scope.
	  		int * f() {
	 			int x = 1;
	 			return &x;
	 		}
	 		main() {
	 			int *p = f();
	 			printf("%d", *p);
	 		}
  */
class Dangling {
// class Lifetime {
	static Integer getInteger() {
	  Integer x = 1;
	  return x;
	}
	public static void main(String args[]) {
  		/* 1. Java references can only assigned with:
  		 	- null
  		 	- the result of new from a compatible type.
  		 	- a reference of a compatible type.  */
		// A a = 1000;				// error

 		// 2. Java checks array index out of bound at runtime.
		int a[] = new int[10];
  		// a[10] = 1;	// runtime execption  ArrayIndexOutOfBoundsException

		/* 3. Java does not allow de-allocatation.
		   4. There is no * and &, simple types will not be garbages.
			 All reference types are allocated on heap so their references
			   can be passed around. */
  		Integer i = getInteger();
  	}
}

// Obsolete objects are inaccessible but not garbages and cannot be garbage collected.
class Obsolete {
	private A a;
	public void bad() {
		a = new A(); // a is used here and may be in other methods.
	} /* This create dependency that bad() must be called before using a.
	While the insatnce is alive, if no other methods use a then it is
	 an obsolete object. We can provide a nullify method, but it made
	 programming more complicated. */
	public void nullA() { a = null; }

	// If a is used only in the method then it should be local.
	public void good() {
		A a = new A(); 	// a is used here only.
	}
}

/* Memory leak is the situation that the heap is losing more and more
  memory and eventually run out.
Simple rules:
 - We do not need to manage memory if we do not create our own data structures.
 - When deleting an object, make sure the object is garbage collectible. */
class Stack {
	private Object [] a;
	private int top = 0;
	public Stack(int n) { a = new Object[n]; }
	public void push(Object o) { a[top++] = o; }
	public Object pop() { return a[--top]; }
/*	public Object pop() {
		Object o = a[--top];
		a[top] = null;
		return o;
	}
*/
}
// class MemoryLeak {
class Lifetime {
	public static void main(String args[]) {
		Stack s = new Stack(1000);
		for(int i = 0; i < 1000; i++)
			s.push(i);

		for(int i = 0; i < 1000; i++)
			s.pop(); // All elements in the Stack are Obsolete.
	}
}
