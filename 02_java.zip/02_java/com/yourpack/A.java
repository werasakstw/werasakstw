package com.yourpack;

public class A {
	public void f() {
		System.out.println("com.yourpack.A.f()");
	}
}