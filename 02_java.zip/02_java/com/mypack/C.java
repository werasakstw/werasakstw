package com.mypack;

public class C {
    public static final String GREET = "Hello";
}
