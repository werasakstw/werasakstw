/* A class is defined with class definition:
		class <name> { <members> }
<members> may be data, method, or class.  */
class A {
	int x = 1;				// data member
	void f() {				// method member
		System.out.println("A.f");
	}
	class B { 				// class member
		void f() {
			System.out.println("B.f");
		}
	}
}
// . is the projection operator, for accessing object members.
class ATest {
// class Classes {
	public static void main(String[] args) {
		A a = new A();
		System.out.println(a.x);
		a.f();

		A.B b = a.new B();
		b.f();
	}
}
//------------------------------------------------

/* Modifiers define property of members which may be
1. Visibility:  */
class B {
 	private int w = 1;		// private
 	int x = 2;				// default (package public)
 	protected int y = 3;	// protected (for subclasses)
 	public int z = 4;
 }
 class BTest {
 // class Classes {
 	public static void main(String[] args) {
 		B b = new B();
 		// System.out.print(b.w);		// compile time error
 		System.out.print(b.x + "," + b.y + "," + b.z);
 	}
} // More detail visibility in package and subclass.

// 2. Mutability.
class Mutability {
	// A 'final' simple type variable is immutable.
	final int x = 1;
	void f() {
		// x = 2;			// compile-time error
	}

	// A 'final' reference is immutable, but not its value.
	class A {
		int x;
		void setX(int x) { this.x = x; }
	}
	void g() {
		final A a = new A();
		a.setX(1);
		// a = new A();		// Modify 'a' is not allowed.
	}

	// A 'final' method cannot be overrided.
	class B {
		final void f() {}
	}
	class C extends B {
		// void f() {}			// compile-time error
	}

	// A 'final' class cannot be extended.
	final class D {}
	// class E extends D {}	// compile-time error
}
