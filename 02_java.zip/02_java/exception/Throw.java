import java.io.*;
import java.sql.*;
class BadThrow {
// class Throw {
	public static void main(String args[]) {
		String s = "John";
		try {
			if (s.equals("John"))
				throw new Exception();			// Bad throw
			System.out.println("Hello! " + s);
		} catch (Exception e) {
			System.out.println("Bye.");
		}
	}
}
/* Do not use exceptions for controls, 'if' is better.
		if (s.equals("John"))
			System.out.println("Bye.");
		else
			System.out.println("Hello! " + s);

Throw statement and its try-catch block should be in different scope.
Exceptions may carry error information from the callee to the caller.
 */
class GoodThrow {
// class Throw {
	static void greet(String n) throws Exception {
		if (n.equals("John"))
			throw new Exception();
		System.out.println("Hello! " + n);
	}
	public static void main(String args[]) {
		try {
			greet("John");
		} catch (Exception e) {
			System.out.println("Bye.");
		}
	}
}
/* 'throws' expressions just tell the compiler
 that the method may throw these kinds of exception.

A method may throws any number of exception types, including zero,
 but there will be no more than one exception that actually thrown.

A statement that calls method which throws exceptions must be
 in the try block that catch the exceptions.  */
class Throws {						// The sequence is no matter.
// class Throw {
	static void greet(String n) throws IOException, SQLException {
		// The declared throws exceptions may not actually thrown inside the method.
		if (n.equals("John"))
			throw new IOException();
		System.out.println("Hello! " + n);
	}
	public static void main(String args[]) {
		try {
			greet("John");
		}  catch (SQLException e) {  // All the throws exceptions must be catched.
			System.out.println("SQL.");
		} catch (IOException e) {
			System.out.println("IO.");
		} // Use Exception for default catching.

		/* Java 7 Catching Multiple Exceptions in a Single Catch Block.

		catch(SQLException | IOException e) {
			// handle e
		}
		 */
	}
}

/* Un-checked Exceptions are exceptions that may or may not be catch.
		Error
		RuntimeException     */
class Uncheck {
// class Throw {
	static void greet(String n) {
		if (n.equals("John"))
			throw new RuntimeException();
		System.out.println("Hello! " + n);
	}
	public static void main(String args[]) {
		greet("John");
	}
}

/* By default, Throwable objects may contains string
 as a message. If not enough we can define our Exception. */
 class MyException extends Exception {
 	private int x;
 	MyException(String msg, int x) { super(msg); this.x = x; }
 	public int getX() { return x; }
 }
 class MyExceptionTest {
 // class Throw {
 	static void hello(String n) throws MyException {
 		if (n.equals("John"))
 			throw new MyException("bad", 1);
 		System.out.println("Hello! " + n);
 	}
 	public static void main(String args[]) {
 		try {
 			hello("John");
 		} catch (MyException e) {
 				System.out.println(e.getMessage() + "," + e.getX());
 		}
 	}
 }

/* Assertion is something that supposed to be true
 without proof. We use assertion for program validation.
Boolean expressions are injected into program codes where
 they are supposed to be true using 'assert', if the
 expression is false an exception is thrown.
		assert(<expression>, <exception>)
Normal runtime ignores all 'assert', we must enable with -ea.
  e.g.      java -ea Throw						*/
class Assert {
// class Throw {
	public static void main(String args[]) {
		int x = Integer.parseInt("0");

		assert x == 1 : "Bad Value";
		// if (!(x == 1)) throw new Exception("Bad Value"));
	}
}
