/* java.lang.Throwable
 		java.lang.Error
 		java.lang.Exception
 			java.lang.RuntimeException
 				java.lang.ArrayIndexOutOfBoundsException
 				java.lang.ArithmeticException
 				.....
 			java.io.IOException
 			java.sql.SQLException
			.....
 */

/*
1. Print: thread, exception class, and message.
2.        activation stack.
3. Terminate the JVM.
 */
class DefualtHandle {
// class Except {
	public static void main(String args[]) {
		System.out.println("Hello!  " + args[0]);
	} // java.lang.ArrayIndexOutOfBoundsException
}

class TryCatch {
// class Except {
	public static void main(String args[]) {
		try {
			System.out.println("Hello!  "+ args[0]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Hello! whoever you are. ");
		}
		System.out.println("Goodbye.");
	}
}

/* A try block can throw more one kind of exceptions.
But only the first one is actually thrown. */
class MultipleCatch {
// class Except {
	public static void main(String args[]) {
		try {
			int i1 = Integer.parseInt("10");
			int i2 = Integer.parseInt("2");
			System.out.println(i1 / i2);
		} catch (NumberFormatException e) {
			System.out.println(e.getMessage());
		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
/* Bad :
		try {
			int i1 = Integer.parseInt("10");
			int i2 = Integer.parseInt("2");
			System.out.println(i1 / i2);
		} catch(Exception e) {
			if (e instanceof NumberFormatException)
				// handle NumberFormatException
			else if (e instanceof ArithmeticException)
				// handle ArithmeticException
			.......
		}   */

/* Try-Catch-Finally:
				try {
					// try block
				} catch(Ex1 e) {
					// catch block
				} catch(Ex2 e) {
					// catch block
				}
				....
				[ finally {
					// finally block
				} ]
A 'try' may follwed by at least one 'catch' and ended with
 one optional 'finally'.
If a 'try' has a 'finally' the 'catch' is optional.

If a 'try' is executed, the 'finally' must be executed before
 going on, even there is a 'return' or a nested execption is thrown.
*/
// class Finally {
class Except {
	static void test(String name) {
		try {
			if (name.equals("john"))
				// throw new Exception();
				return;
			System.out.println("Hello!");
		} catch (Exception e) {
			System.out.println("Catch");
		} finally {
			System.out.println("Finally");
		}
		System.out.println("End");
	}
	public static void main(String args[]) {
		test("john");
		System.out.println();
		test("jack");
	}
}
