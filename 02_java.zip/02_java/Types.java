/* C.
	int x = 1;		// x is an integer variable.
	int *p = &x;	// p is a pointer to integer.

C++  (Suppose A is a class.)
	A a;			// a is a variable of class A.
	A *ap;		// ap is a pointer to instance of class A.

Java is not a pure object-oriented language.
There are two kinds of types:
 - Value type: (simple or primitive Types) e.g.
	 byte, short, int, long, float, double, char and boolean.
 - Reference types: all classes. */
class A { }
class ATest {
	void f() {
		// A simple type variable has name and value.
		int x = 1;	// 'x' is a variable of int type.
		/* Java has no & operator, it is not allow to have
		 pointers (or reference) to simple types. */

		// A reference type object has name, reference and value.
		A a;			  // 'y' is a reference to instance of class A
		a = new A();
		/* An object value must be explicitly created with 'new'.
		Java does not need * to define references and all reference
		is automatic de-referencing when accessing value. */
	}
}
//-----------------------------------------------------------

// Java handles value types and reference types differently.
class B {
	int x;
	B(int x) { this.x = x; }
	void inc() { x++; }
}
class Comparision {
// class Types {
	public static void main(String args[]) {
		// Value types are compared by value.
		int a = 1, b = 1;
		System.out.println(a == b);	// true

		// Reference types are compared by reference.
		B b1 = new B(1);
		B b2 = new B(1);
		System.out.println(b1 == b2);	// false
	}
}

class Assignment {
// class Types {
	public static void main(String args[]) {
		// Value types are assined by value.
		int a = 1, b = 2;
		a = b;
		System.out.println(a + ", " + b);	   // 2, 2
		b = 3;
		System.out.println(a + ", " + b);	   // 2, 3

		// Reference types are assigned by reference.
		B b1 = new B(1);
		B b2 = new B(2);
		b1 = b2;
		System.out.println(b1.x + ", " + b2.x);	// 2, 2
		b1.inc();
		System.out.println(b1.x + ", " + b2.x);	// 3, 3
	}
}

// class Passing {
class Types {
	static void f(int x) { x++; }
	static void g(B b) { b.inc(); }
	public static void main(String args[]) {
		// Value type are passed by value.
		int x = 0;
		f(x);		// pass value
		System.out.println(x);		// 0

		// Reference type are passed by reference.
		B b = new B(0);
		g(b);		// pass reference
		System.out.println(b.x);	// 1
	}
}
