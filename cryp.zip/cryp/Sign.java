import java.security.PrivateKey;
import java.security.Signature;
class Sign {
	public static void main(String args[]) throws Exception {
		Signature sig = Signature.getInstance("DSA");
		sig.initSign((PrivateKey)FileUtil.readObjFile("privatekey"));		// private key to be used
		sig.update(FileUtil.readFile("hello.txt"));							// file to be signed
		FileUtil.writeFile("hello.txt.sig", sig.sign());					// signature file
		System.out.println("Ok");
	}
}
