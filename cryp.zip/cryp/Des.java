import java.security.Key;
import javax.crypto.Cipher;
class Des {
	public static void main(String args[]) throws Exception {
		Key k = (Key) FileUtil.readObjFile("key");
		Cipher c = Cipher.getInstance("DES");		// "DES/ECB/PKCS5Padding"

			// encode
		c.init(Cipher.ENCRYPT_MODE, k);
		byte [] b = c.doFinal(FileUtil.readFile("hello.txt"));
		FileUtil.writeFile("tmp.1", b);

			// decode
		c.init(Cipher.DECRYPT_MODE, k);
		b = c.doFinal(FileUtil.readFile("tmp.1"));
		FileUtil.writeFile("tmp.2", b);

		System.out.println("Ok");
	}
}
