import java.security.Key;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
public class MyUtil {
	public static String KEY = "hello123";
	public static Key getKey(String pwd) throws Exception {
		byte [] pw = pwd.getBytes(); // length >= 8
		DESKeySpec ks = new DESKeySpec(pw);
		SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
		return kf.generateSecret(ks);
	}
}
