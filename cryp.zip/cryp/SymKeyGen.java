import javax.crypto.*;
import java.security.*;
class SymKeyGen {
	public static void main(String args[]) {
		KeyGenerator kg = null;
		try {
			kg = KeyGenerator.getInstance("DES");
		} catch(NoSuchAlgorithmException e) {
			System.out.println(e);
			return;
		}
		kg.init(new SecureRandom());
		Key k = kg.generateKey();
		try {
			FileUtil.writeObjFile("key", k);
		} catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("Ok");
	}
}
