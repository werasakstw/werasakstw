import java.io.Serializable;
import javax.crypto.Cipher;
import javax.crypto.SealedObject;
class MyObj implements Serializable {
	private static final long serialVersionUID = 1L;
	private int x;
	MyObj(int x) { this.x = x; }
	public int getX() { return x; }
}
class SealedObj {
	public static void main(String args[]) throws Exception {
		Cipher c = Cipher.getInstance("DES");

			// encode
		c.init(Cipher.ENCRYPT_MODE, MyUtil.getKey(MyUtil.KEY));
		SealedObject so = new SealedObject(new MyObj(123), c);
		FileUtil.writeObjFile("tmp.1", so);

			// decode
		c.init(Cipher.DECRYPT_MODE, MyUtil.getKey(MyUtil.KEY));
		MyObj mo = (MyObj) so.getObject(c);
		System.out.println(mo.getX());
	}
}
