import java.security.PublicKey;
import java.security.Signature;
class Verify {
	public static void main(String args[]) throws Exception {
		Signature sig = Signature.getInstance("DSA");
		sig.initVerify((PublicKey)FileUtil.readObjFile("publickey"));		// public key to be used
		sig.update(FileUtil.readFile("hello.txt"));							// file to be verified
		if (sig.verify(FileUtil.readFile("hello.txt.sig")))					// signature file
			System.out.println("Valid");
		else
			System.out.println("InValid");
	}
}
