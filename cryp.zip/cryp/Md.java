import java.io.*;
import java.security.*;
class Md {
	static void printBytes(byte b[]) {
		for(int i = 0; i < b.length; i++) {
			if (i != 0)
				System.out.print(":");
			int x = b[i] & 0xff;
			String s = Integer.toHexString(x);
			if (s.length() == 1)
				System.out.print("0");
			System.out.print(s);
		}
	}
	public static void main(String args[]) throws IOException {
		MessageDigest md = null;
		try {		// "SHA-1" or "MD5"
			md = MessageDigest.getInstance("SHA-1");
			// md = MessageDigest.getInstance("MD5");
		} catch(NoSuchAlgorithmException e) {
			System.out.println(e);
			return;
		}
		md.update(FileUtil.readFile("hello.txt"));
		byte [] b = md.digest();
		printBytes(b);
	}
}
